/*
 * Copyright (c) 2006-2020, RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2020-09-15     chen1       the first version
 */
#ifndef __DEVICEGENERAL_H__
#define __DEVICEGENERAL_H__

#include <rtthread.h>
#include "flexible_button.h"
#include <stdint.h>
#include <stdlib.h>
#include <rtdevice.h>
#include <board.h>

//定义flash操作函数
void stm32_flash_read (rt_uint32_t addr, const rt_uint8_t *buf, size_t size);
void stm32_flash_write(rt_uint32_t addr, const rt_uint8_t *buf, size_t size);
int  stm32_flash_erase(rt_uint32_t addr, size_t size);


//反馈灯列表

//#define PIN_KEY0        GET_PIN(A, 10)
//#define PIN_KEY1        GET_PIN(A, 8)
//#define PIN_KEY2        GET_PIN(B, 14)
//#define PIN_KEY3        GET_PIN(B, 13)
//#define PIN_KEY4        GET_PIN(B, 15)
//#define PIN_KEY5        GET_PIN(A, 9)
//#define PIN_KEY6        GET_PIN(B, 12)

#define PIN_KEY0        GET_PIN(A, 8) //改版前
#define PIN_KEY1        GET_PIN(A, 10)
#define PIN_KEY2        GET_PIN(A, 9)
#define PIN_KEY3        GET_PIN(B, 15)
#define PIN_KEY4        GET_PIN(B, 14)
#define PIN_KEY5        GET_PIN(B, 13)
#define PIN_KEY6        GET_PIN(B, 12)

#define HWTIMER_DEV_NAME   "timer0"     /* 定时器名称 */
//
#define FLAG_FLASH             0x8019000
//CAN ID 储存
#define CAN_ID_Number_adder    0x8019010
//SN 储存
#define Serial_Number_adder    0x8019050
//long and short
#define long_and_short_adder   0x8019100
//back kg
#define back_led_kg_adder      0x8019130
//back id
#define back_led_id_adder      0x8019160
//back order
#define back_led_or_adder      0x8019190
//seelp id
#define sleep_id_adder         0x8019200
//seelp or
#define sleep_or_adder         0x8019210
//relay_id
#define relay_id_adder         0x8019370
//relay_or
#define relay_or_adder         0x8019510
//relay_st
#define relay_st_adder         0x8019670
//relay_ys
#define relay_ys_adder         0x8019700

//CAN通信列表
#define CAN_LED      GET_PIN(A, 5)
#define CAN_DEV_NAME       "can1"
//四舍五入
//#define ROUND_TO_UINT32(x)     ((rt_uint32_t)(x)+0.5)>(x) ? ((rt_uint32_t)(x)) : ((rt_uint32_t)(x)+1)
struct Butt{

    rt_uint8_t  key_index[7];           //
    rt_uint8_t short_long[7];           //长按或短按

};
//继电器结构体
struct Relay{

    rt_uint8_t To_Relay[4];             //继电器
    rt_uint8_t To_Flag[4];              //是否进入
    rt_uint8_t To_state[4];             //将要更改的状态
    rt_uint8_t Sava_id[4][10];          //对方ID
    rt_uint8_t Sava_order[4][10];       //对方指令
    rt_uint8_t Sava_state[4][10];       //对方发来的状态
    rt_uint8_t Sava_delay[4][10];       //延时多少动作
    rt_uint8_t times[4];
};

struct Break{
    rt_uint8_t on_off[7];               //是否开启反馈灯
    rt_uint8_t number[7];               //开启值
    rt_uint8_t it_id[7];                //对方返回id
    rt_uint8_t it_state[7];             //对方返回状态也是指令
    rt_uint8_t LED[7];                  //反馈灯
};
struct Time{
    rt_uint8_t index;                 //time1的增加变量
    rt_uint8_t Seelp;                 //sleep的增加变量
};
rt_uint8_t Serial_Number[9];            //SN
rt_uint8_t light = 0,all=0;
rt_uint16_t ID_Number;                  //ID

rt_uint16_t tem_sem[1];                 //临时数据

rt_uint16_t Sleep_id[2],Sleep_or[2];    //睡眠指令储存

struct rt_device_pwm *pwm_dev;          //pwm句柄
static rt_device_t    can_dev;          //can句柄

//返回信号
static rt_mq_t msg_bk_id = RT_NULL;
static rt_mq_t msg_bk_or = RT_NULL;
static rt_mq_t msg_bk_st = RT_NULL;

//接收信号
static rt_mq_t msg_id = RT_NULL;
static rt_mq_t msg_or = RT_NULL;
static rt_mq_t msg_st = RT_NULL;

static struct rt_semaphore rx_sem;

static rt_timer_t timer,sleep;


//按键枚举值
typedef enum
{
    USER_BUTTON_0,
    USER_BUTTON_1,
    USER_BUTTON_2,
    USER_BUTTON_3,
    USER_BUTTON_4,
    USER_BUTTON_5,
    USER_BUTTON_6,
    USER_BUTTON_MAX
} user_button_t;

static flex_button_t user_button[USER_BUTTON_MAX];

struct rt_can_msg msg = {0};
struct rt_can_msg butt = {0};

#endif
