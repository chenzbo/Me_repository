//#include <rtthread.h>
//#include "flexible_button.h"
//#include <stdint.h>
//#include <stdlib.h>
//#include <rtdevice.h>
//#include <board.h>
//
//
////定义flash操作函数
//void stm32_flash_read (rt_uint32_t addr, const rt_uint8_t *buf, size_t size);
//void stm32_flash_write(rt_uint32_t addr, const rt_uint8_t *buf, size_t size);
//int  stm32_flash_erase(rt_uint32_t addr, size_t size);
//
//#define HWTIMER_DEV_NAME   "timer0"     /* 定时器名称 */
////
//#define FLAG_FLASH             0x8019000
////CAN ID 储存
//#define CAN_ID_Number_adder    0x8019010
////SN 储存
//#define Serial_Number_adder    0x8019050
////long and short
//#define long_and_short_adder   0x8019100
////back kg
//#define back_led_kg_adder      0x8019130
////back id
//#define back_led_id_adder      0x8019160
////back order
//#define back_led_or_adder      0x8019190
////seelp id
//#define seelp_id_adder         0x8019200
////seelp or
//#define seelp_or_adder         0x8019210
////relay_id
//#define relay_id_adder         0x8019370
////relay_or
//#define relay_or_adder         0x8019650
////relay_st
//#define relay_st_adder         0x8019810
////relay_ys
//#define relay_ys_adder         0x8019840
////四舍五入
////#define ROUND_TO_UINT32(x)     ((rt_uint32_t)(x)+0.5)>(x) ? ((rt_uint32_t)(x)) : ((rt_uint32_t)(x)+1)
////反馈灯列表
//
//#define PIN_KEY0        GET_PIN(A, 10)
//#define PIN_KEY1        GET_PIN(A, 8)
//#define PIN_KEY2        GET_PIN(B, 14)
//#define PIN_KEY3        GET_PIN(B, 13)
//#define PIN_KEY4        GET_PIN(B, 15)
//#define PIN_KEY5        GET_PIN(A, 9)
//#define PIN_KEY6        GET_PIN(B, 12)
//
////#define PIN_KEY0        GET_PIN(A, 8) //改版前
////#define PIN_KEY1        GET_PIN(A, 10)
////#define PIN_KEY2        GET_PIN(A, 9)
////#define PIN_KEY3        GET_PIN(B, 15)
////#define PIN_KEY4        GET_PIN(B, 14)
////#define PIN_KEY5        GET_PIN(B, 13)
////#define PIN_KEY6        GET_PIN(B, 12)
////继电器通道列表
//#define JDQ_1_K        GET_PIN(B, 1)//GET_PIN(B, 8)//改版前
//#define JDQ_1_G        GET_PIN(B, 0)//GET_PIN(C, 14)
//#define JDQ_2_K        GET_PIN(A, 7)//GET_PIN(B, 0)
//#define JDQ_2_G        GET_PIN(A, 6)//GET_PIN(B, 1)
//#define JDQ_3_K        GET_PIN(B, 8)//GET_PIN(A, 7)
//#define JDQ_3_G        GET_PIN(C, 14)//GET_PIN(A, 6)
////通道变量
//
//rt_uint32_t  Index_1=0,Index_2=0,Index_3=0;
//rt_uint32_t  relay_1=0x0c,relay_2=0x0c,relay_3=0x0c;
////
//rt_uint8_t Serial_Number[9];    //SN
////
//rt_uint16_t ID_Number;          //ID
////短按与长按
//rt_uint8_t  short_or_long[7];
////输出
//rt_uint16_t MSG_CAN[1];      //id
//
//rt_uint16_t relay_id[4][20];      //id
//rt_uint16_t relay_or[4][20];      //指令
//int relay_st[4][20];      //状态
//int relay_ys[4][20];      //延时
//
////反馈
//rt_uint8_t  bk_off_on[7];            //开启或关闭
//rt_uint8_t  bk_index[7];             //反馈触发值
//rt_uint16_t bk_id[7];               //反馈灯id
//rt_uint16_t bk_or[7];               //反馈灯指令
////
//rt_uint8_t  FK_PIN[6][2];            //开启或关闭
////
//rt_uint16_t Sleep_id[2],Sleep_or[2];
////CAN通信列表
//#define CAN_LED      GET_PIN(A, 5)
//#define CAN_DEV_NAME       "can1"
//struct rt_device_pwm *pwm_dev;
//static rt_device_t    can_dev;
//rt_adc_device_t adc_dev;
////返回信号
//static rt_mq_t msg_bk_id = RT_NULL;
//static rt_mq_t msg_bk_or = RT_NULL;
//static rt_mq_t msg_bk_st = RT_NULL;
//
////接收信号
//static rt_mq_t msg_id = RT_NULL;
//static rt_mq_t msg_or = RT_NULL;
//static rt_mq_t msg_st = RT_NULL;
////
//static struct rt_semaphore rx_sem;
//static struct rt_thread CAN_Thread;
//static rt_uint8_t CAN_thread_stack[1024];
////
//struct rt_can_msg msg = {0};
////按键专属发送
//struct rt_can_msg key_msg = {0};
//struct rt_can_msg relay_msg = {0};
//
//rt_hwtimerval_t timeout_s;      /* 定时器超时值 */
//rt_device_t hw_dev = RT_NULL;   /* 定时器设备句柄 */
////
//rt_uint8_t p_cnt_1=0,p_cnt_2=0,p_cnt_3=0,p_cnt_4=0,sleep_cnt=0;
//rt_uint8_t p1=0,p2=0,p3=0,p4=0;
//static rt_timer_t timer1,timer2,timer3,sleep;
//typedef enum
//{
//    USER_BUTTON_0,
//    USER_BUTTON_1,
//    USER_BUTTON_2,
//    USER_BUTTON_3,
//    USER_BUTTON_4,
//    USER_BUTTON_5,
//    USER_BUTTON_6,
//    USER_BUTTON_MAX
//} user_button_t;
//static flex_button_t user_button[USER_BUTTON_MAX];
//
//static void timeout1(void *parameter)
//{
//    if (p_cnt_1++ == 30)//10次停止
//    {
//        rt_timer_stop(timer1);
//        Index_1 = 1;
//        relay_1 = 0x0c;
//        p_cnt_1 = 0;
//    }else if(p_cnt_1 > 30){
//        rt_timer_stop(timer1);
//        Index_1 = 0;
//        p_cnt_1 = 0;
//    }
//}
//static void timeout2(void *parameter)
//{
//    if (p_cnt_2++ == 30)//20次停止
//    {
//        rt_timer_stop(timer2);
//        Index_2 = 1;
//        relay_2 = 0x0c;
//        p_cnt_2 = 0;
//    }else if(p_cnt_2 > 30){
//        rt_timer_stop(timer2);
//        Index_2 = 0;
//        p_cnt_2 = 0;
//    }
//}
//static void timeout3(void *parameter)
//{
//    if (p_cnt_3++ == 30)//30次停止
//    {
//        rt_timer_stop(timer3);
//        Index_3 = 1;
//        relay_3 = 0x0c;
//        p_cnt_3 = 0;
//    }else if(p_cnt_3 > 30){
//        rt_timer_stop(timer3);
//        Index_3 = 0;
//        p_cnt_3 = 0;
//    }
//}
//
//static void Sleep_bk(void *parameter)
//{
//    if (sleep_cnt++ == 9)//10次停止
//    {
//        rt_timer_stop(sleep);
//        rt_pin_write(FK_PIN[6][1], 0);
//        sleep_cnt = 0;
//    }else if(sleep_cnt > 9){
//        rt_timer_stop(sleep);
//        sleep_cnt = 0;
//    }
//}
//
////初始化PWM
//void hwtimer_sample(void)
//{
//    timer1 = rt_timer_create("timer1", timeout1,RT_NULL, 1000, RT_TIMER_FLAG_PERIODIC);
//    timer2 = rt_timer_create("timer2", timeout2,RT_NULL, 1000, RT_TIMER_FLAG_PERIODIC);
//    timer3 = rt_timer_create("timer3", timeout3,RT_NULL, 1000, RT_TIMER_FLAG_PERIODIC);
//    sleep =  rt_timer_create("sleep", Sleep_bk,RT_NULL, 1000, RT_TIMER_FLAG_PERIODIC);
//}
//
//void but_send_1(void)
//{
//
//    if (bk_id[0] == 0xff)
//    {
//        key_msg.data[0] = 0xff;
//        rt_device_write(can_dev, 0, &key_msg, sizeof(key_msg));
//        MSG_CAN[0] = ID_Number;
//        rt_mq_send(msg_id, &MSG_CAN, sizeof(MSG_CAN[0]));
//        MSG_CAN[0] = 0xff;
//        rt_mq_send(msg_or, &MSG_CAN, sizeof(MSG_CAN[0]));
//    } else
//    {
//        key_msg.data[0] = 1;
//        rt_device_write(can_dev, 0, &key_msg, sizeof(key_msg));
//        MSG_CAN[0] = ID_Number;
//        rt_mq_send(msg_id, &MSG_CAN, sizeof(MSG_CAN[0]));
//        MSG_CAN[0] = 1;
//        rt_mq_send(msg_or, &MSG_CAN, sizeof(MSG_CAN[0]));
//    }
//}
//void but_send_2(void)
//{
//    if (bk_id[1] == 0xff)
//    {
//        key_msg.data[0] = 0xff;
//        rt_device_write(can_dev, 0, &key_msg, sizeof(key_msg));
//        MSG_CAN[0] = ID_Number;
//        rt_mq_send(msg_id, &MSG_CAN, sizeof(MSG_CAN[0]));
//        MSG_CAN[0] = 0xff;
//        rt_mq_send(msg_or, &MSG_CAN, sizeof(MSG_CAN[0]));
//    } else
//    {
//        key_msg.data[0] = 2;
//        rt_device_write(can_dev, 0, &key_msg, sizeof(key_msg));
//        MSG_CAN[0] = ID_Number;
//        rt_mq_send(msg_id, &MSG_CAN, sizeof(MSG_CAN[0]));
//        MSG_CAN[0] = 2;
//        rt_mq_send(msg_or, &MSG_CAN, sizeof(MSG_CAN[0]));
//    }
//
//}
//void but_send_3(void)
//{
//    if (bk_id[2] == 0xff)
//    {
//        key_msg.data[0] = 0xff;
//        rt_device_write(can_dev, 0, &key_msg, sizeof(key_msg));
//        MSG_CAN[0] = ID_Number;
//        rt_mq_send(msg_id, &MSG_CAN, sizeof(MSG_CAN[0]));
//        MSG_CAN[0] = 0xff;
//        rt_mq_send(msg_or, &MSG_CAN, sizeof(MSG_CAN[0]));
//    } else {
//        key_msg.data[0] = 3;
//        rt_device_write(can_dev, 0, &key_msg, sizeof(key_msg));
//        MSG_CAN[0] = ID_Number;
//        rt_mq_send(msg_id, &MSG_CAN, sizeof(MSG_CAN[0]));
//        MSG_CAN[0] = 3;
//        rt_mq_send(msg_or, &MSG_CAN, sizeof(MSG_CAN[0]));
//    }
//}
//void but_send_4(void)
//{
//    if (bk_id[3] == 0xff)
//    {
//        key_msg.data[0] = 0xff;
//        rt_device_write(can_dev, 0, &key_msg, sizeof(key_msg));
//        MSG_CAN[0] = ID_Number;
//        rt_mq_send(msg_id, &MSG_CAN, sizeof(MSG_CAN[0]));
//        MSG_CAN[0] = 0xff;
//        rt_mq_send(msg_or, &MSG_CAN, sizeof(MSG_CAN[0]));
//    } else
//    {
//        key_msg.data[0] = 4;
//        rt_device_write(can_dev, 0, &key_msg, sizeof(key_msg));
//        MSG_CAN[0] = ID_Number;
//        rt_mq_send(msg_id, &MSG_CAN, sizeof(MSG_CAN[0]));
//        MSG_CAN[0] = 4;
//        rt_mq_send(msg_or, &MSG_CAN, sizeof(MSG_CAN[0]));
//    }
//}
//void but_send_5(void)
//{
//    if (bk_id[4] == 0xff) {
//        key_msg.data[0] = 0xff;
//        rt_device_write(can_dev, 0, &key_msg, sizeof(key_msg));
//        MSG_CAN[0] = ID_Number;
//        rt_mq_send(msg_id, &MSG_CAN, sizeof(MSG_CAN[0]));
//        MSG_CAN[0] = 0xff;
//        rt_mq_send(msg_or, &MSG_CAN, sizeof(MSG_CAN[0]));
//    } else {
//        key_msg.data[0] = 5;
//        rt_device_write(can_dev, 0, &key_msg, sizeof(key_msg));
//        MSG_CAN[0] = ID_Number;
//        rt_mq_send(msg_id, &MSG_CAN, sizeof(MSG_CAN[0]));
//        MSG_CAN[0] = 5;
//        rt_mq_send(msg_or, &MSG_CAN, sizeof(MSG_CAN[0]));
//    }
//}
//void but_send_6(void)
//{
//    if (bk_id[5] == 0xff) {
//        key_msg.data[0] = 0xff;
//        rt_device_write(can_dev, 0, &key_msg, sizeof(key_msg));
//        MSG_CAN[0] = ID_Number;
//        rt_mq_send(msg_id, &MSG_CAN, sizeof(MSG_CAN[0]));
//        MSG_CAN[0] = 0xff;
//        rt_mq_send(msg_or, &MSG_CAN, sizeof(MSG_CAN[0]));
//    } else {
//        key_msg.data[0] = 6;
//        rt_device_write(can_dev, 0, &key_msg, sizeof(key_msg));
//        MSG_CAN[0] = ID_Number;
//        rt_mq_send(msg_id, &MSG_CAN, sizeof(MSG_CAN[0]));
//        MSG_CAN[0] = 6;
//        rt_mq_send(msg_or, &MSG_CAN, sizeof(MSG_CAN[0]));
//    }
//
//}
//void but_send_7(void)
//{
//    key_msg.data[0] = 7;
//    rt_device_write(can_dev, 0, &key_msg, sizeof(key_msg));
//}
////按键1
//static void btn_0_cb(flex_button_t *btn)
//{
//    if (btn->event==FLEX_BTN_PRESS_DOWN && short_or_long[0] == 1)
//    {
//        but_send_1();
//    }else if (btn->event==FLEX_BTN_PRESS_LONG_HOLD && short_or_long[0] == 2) {
//        but_send_1();
//    }else if (btn->event==FLEX_BTN_PRESS_LONG_HOLD_UP && short_or_long[0] == 2)
//    {
//        but_send_1();
//    }else if (btn->event==FLEX_BTN_PRESS_DOWN && short_or_long[0] == 0xff){
//        Index_1 = 1;
//        relay_1 = 0x0b;
//        rt_pin_write(FK_PIN[0][1], 1);
//    }
//}
////按键2
//static void btn_1_cb(flex_button_t *btn)
//{
//    if (btn->event==FLEX_BTN_PRESS_DOWN && short_or_long[1] == 1)
//    {
//        but_send_2();
//    }else if (btn->event==FLEX_BTN_PRESS_LONG_HOLD && short_or_long[1] == 2) {
//        but_send_2();
//    }else if (btn->event==FLEX_BTN_PRESS_LONG_HOLD_UP && short_or_long[1] == 2)
//    {
//        but_send_2();
//    }else if (btn->event==FLEX_BTN_PRESS_DOWN && short_or_long[1] == 0xff){
//        Index_1 = 1;
//        relay_1 = 0x0c;
//        rt_pin_write(FK_PIN[0][1], 0);
//    }
//}
////按键3
//static void btn_2_cb(flex_button_t *btn)
//{
//    if (btn->event==FLEX_BTN_PRESS_DOWN && short_or_long[2] == 1)
//    {
//        but_send_3();
//    }else if (btn->event==FLEX_BTN_PRESS_LONG_HOLD && short_or_long[2] == 2)
//    {
//        but_send_3();
//    }else if (btn->event==FLEX_BTN_PRESS_LONG_HOLD_UP && short_or_long[2] == 2)
//    {
//        but_send_3();
//    }else if (btn->event==FLEX_BTN_PRESS_DOWN && short_or_long[2] == 0xff){
//        Index_2 = 1;
//        relay_2 = 0x0b;
//        rt_pin_write(FK_PIN[2][1], 1);
//    }
//}
////按键4
//static void btn_3_cb(flex_button_t *btn)
//{
//    if (btn->event==FLEX_BTN_PRESS_DOWN && short_or_long[3] == 1)
//    {
//        but_send_4();
//    }else if (btn->event==FLEX_BTN_PRESS_LONG_HOLD && short_or_long[3] == 2)
//    {
//        but_send_4();
//    }else if (btn->event==FLEX_BTN_PRESS_LONG_HOLD_UP && short_or_long[3] == 2)
//    {
//        but_send_4();
//    }else if (btn->event==FLEX_BTN_PRESS_DOWN && short_or_long[3] == 0xff){
//        Index_2 = 1;
//        relay_2 = 0x0c;
//        rt_pin_write(FK_PIN[2][1], 0);
//    }
//}
////按键5
//static void btn_4_cb(flex_button_t *btn)
//{
//    if (btn->event==FLEX_BTN_PRESS_DOWN && short_or_long[4] == 1)
//    {
//        but_send_5();
//    }else if (btn->event==FLEX_BTN_PRESS_LONG_HOLD && short_or_long[4] == 2)
//    {
//        but_send_5();
//    }else if (btn->event==FLEX_BTN_PRESS_LONG_HOLD_UP && short_or_long[4] == 2)
//    {
//        but_send_5();
//    }else if (btn->event==FLEX_BTN_PRESS_DOWN && short_or_long[4] == 0xff){
//        Index_3 = 1;
//        relay_3 = 0x0b;
//        rt_pin_write(FK_PIN[4][1], 1);
//    }
//}
////按键6
//static void btn_5_cb(flex_button_t *btn)
//{
//    if (btn->event==FLEX_BTN_PRESS_DOWN && short_or_long[5] == 1)
//    {
//        but_send_6();
//    }else if (btn->event==FLEX_BTN_PRESS_LONG_HOLD && short_or_long[5] == 2)
//    {
//        but_send_6();
//    }else if (btn->event==FLEX_BTN_PRESS_LONG_HOLD_UP && short_or_long[5] == 2)
//    {
//        but_send_6();
//    }else if (btn->event==FLEX_BTN_PRESS_DOWN && short_or_long[5] == 0xff){
//        Index_3 = 1;
//        relay_3 = 0x0c;
//        rt_pin_write(FK_PIN[4][1], 0);
//    }
//}
////按键7
//static void btn_6_cb(flex_button_t *btn)
//{
//    if (btn->event==FLEX_BTN_PRESS_DOWN && short_or_long[6] == 1)
//    {
//        but_send_7();
//    }else if (btn->event==FLEX_BTN_PRESS_LONG_HOLD && short_or_long[6] == 2)
//    {
//        but_send_7();
//    }else if (btn->event==FLEX_BTN_PRESS_LONG_HOLD_UP && short_or_long[6] == 2)
//    {
//        but_send_7();
//    }
//}
//static void button_scan(void *arg)
//{
//    while(1)
//    {
//        flex_button_scan();
//        rt_thread_mdelay(5);
//    }
//}
//static void relay_puls_1(void *arg)
//{
//    while(1)
//    {
//        if(Index_1!=0)
//        {
//            if (relay_1 == 0x0b) {
//                rt_pin_write(JDQ_1_K, 1);//继电器动作
//            }else {
//                rt_pin_write(JDQ_1_G, 1);//继电器动作
//            }
//            Index_1 = 0;
//            rt_thread_mdelay(50);
//            rt_pin_write(JDQ_1_K, 0);//继电器动作
//            rt_pin_write(JDQ_1_G, 0);//继电器动作
//        }
//        rt_thread_mdelay(5);
//    }
//}
//static void relay_puls_2(void *arg)
//{
//    while(1)
//    {
//        if(Index_2!=0)
//        {
//            if (relay_2 == 0x0b) {
//                rt_pin_write(JDQ_2_K, 1);//继电器动作
//            }else {
//                rt_pin_write(JDQ_2_G, 1);//继电器动作
//            }
//            Index_2 = 0;
//            rt_thread_mdelay(50);
//            rt_pin_write(JDQ_2_K, 0);//继电器动作
//            rt_pin_write(JDQ_2_G, 0);//继电器动作
//        }
//        rt_thread_mdelay(5);
//    }
//}
//static void relay_puls_3(void *arg)
//{
//    while(1)
//    {
//        if(Index_3!=0)
//        {
//            if (relay_3 == 0x0b) {
//                rt_pin_write(JDQ_3_K, 1);//继电器动作
//            }else {
//                rt_pin_write(JDQ_3_G, 1);//继电器动作
//            }
//            Index_3 = 0;
//            rt_thread_mdelay(50);
//            rt_pin_write(JDQ_3_K, 0);//继电器动作
//            rt_pin_write(JDQ_3_G, 0);//继电器动作
//        }
//        rt_thread_mdelay(5);
//    }
//}
//
//void bk_light(void)
//{
//    sleep_cnt = 10;
//    rt_pin_write(FK_PIN[6][1], 1);
//}
//static void pwm_order(void *arg)
//{
//    rt_uint8_t id_m[8],or_m[8],light = 0;
//
//    while(1)
//    {
//        if(rt_mq_recv(msg_id, &id_m, sizeof(id_m), RT_WAITING_FOREVER) == RT_EOK && rt_mq_recv(msg_or, &or_m, sizeof(or_m), RT_WAITING_FOREVER) == RT_EOK)
//        {
//            if (or_m[0] == 0xff || (id_m[0] == Sleep_id[0] && or_m[0]== Sleep_or[0]) || (id_m[0] == Sleep_id[1] && or_m[0]== Sleep_or[1]))
//            {
//                rt_pin_write(FK_PIN[0][1], 0);
//                rt_pin_write(FK_PIN[1][1], 0);
//                rt_pin_write(FK_PIN[2][1], 0);
//                rt_pin_write(FK_PIN[3][1], 0);
//                rt_pin_write(FK_PIN[4][1], 0);
//                rt_pin_write(FK_PIN[5][1], 0);
//                memset(bk_index, 0, sizeof(bk_index));
//                if (or_m[0]!=0xff) {
//                    light++;
//                    if (light==1) {
//                        sleep_cnt = 0;
//                        relay_1 = relay_2 = relay_3 = 0x0c;
//                        Index_1 = Index_2 = Index_3 = 1;
//                        rt_timer_start(sleep);
//                    }else {
//                        sleep_cnt = 10;
//                        rt_pin_write(FK_PIN[6][1], 1);
//                        light = 0;
//                    }
//                }else {
//                    relay_1 = relay_2 = relay_3 = 0x0c;
//                    Index_1 = Index_2 = Index_3 = 1;
//                }
//            }
//            for (int x = 0; x < 20; x++)
//            {
//                if (id_m[0] == relay_id[0][x] && or_m[0] == relay_or[0][x])
//                {
//                    if (or_m[0] == 0xff)
//                    {
//                        rt_timer_start(timer1);
//                        relay_1 = relay_st[0][x]; //继电器全关,有额外亮的不能填开关模式
//                        Index_1 = 1;
//                    }else if(light == 0){
//                        if (relay_st[0][x] != 0x0a){
//                            relay_1 == relay_st[0][x] ?( Index_1 = 0): ((Index_1 = 1),(relay_1 = relay_st[0][x]));
//                        }else{
//                            relay_1 == 0x0c ?( relay_1 = 0x0b): (relay_1 = 0x0c);
//                            Index_1 = 1;
//                        }
//                        if (Index_1 != 0){
//                            relay_msg.data[0] = 8;
//                            relay_msg.data[1] = relay_1;
//                            rt_device_write(can_dev, 0, &relay_msg, sizeof(relay_msg));
//                            MSG_CAN[0] = ID_Number;
//                            rt_mq_send(msg_bk_id, &MSG_CAN, sizeof(MSG_CAN[0]));
//                            MSG_CAN[0] = 8;
//                            rt_mq_send(msg_bk_or, &MSG_CAN, sizeof(MSG_CAN[0]));
//                            MSG_CAN[0] = relay_1;
//                            rt_mq_send(msg_bk_st, &MSG_CAN, sizeof(MSG_CAN[0]));
//                        }
//                    }
//                    bk_light();
//                    light = 0;
//                }
//                if (id_m[0] == relay_id[1][x] && or_m[0] == relay_or[1][x])
//                {
//                    if (or_m[0] == 0xff)
//                    {
//                        rt_timer_start(timer2);
//                        relay_2 = relay_st[1][x]; //继电器全关,有额外亮的不能填开关模式
//                        Index_2 = 1;
//                    }else if(light == 0){
//                        if (relay_st[1][x] != 0x0a){
//                            relay_2 == relay_st[1][x] ?( Index_2 = 0): ((Index_2 = 1),(relay_2 = relay_st[1][x]));
//                        }else{
//                            relay_2 == 0x0c ?( relay_2 = 0x0b): (relay_2 = 0x0c);
//                            Index_2 = 1;
//                        }
//                        if (Index_2 != 0){
//                            relay_msg.data[0] = 9;
//                            relay_msg.data[1] = relay_2;
//                            rt_device_write(can_dev, 0, &relay_msg, sizeof(relay_msg));
//                            MSG_CAN[0] = ID_Number;
//                            rt_mq_send(msg_bk_id, &MSG_CAN, sizeof(MSG_CAN[0]));
//                            MSG_CAN[0] = 9;
//                            rt_mq_send(msg_bk_or, &MSG_CAN, sizeof(MSG_CAN[0]));
//                            MSG_CAN[0] = relay_2;
//                            rt_mq_send(msg_bk_st, &MSG_CAN, sizeof(MSG_CAN[0]));
//                        }
//                    }
//                    bk_light();
//                    light = 0;
//
//                }
//                if (id_m[0] == relay_id[2][x] && or_m[0] == relay_or[2][x])
//                {
//                    if (or_m[0] == 0xff)
//                    {
//                        rt_timer_start(timer3);
//                        relay_3 = relay_st[2][x]; //继电器全关,有额外亮的不能填开关模式
//                        Index_3 = 1;
//                    }else if(light == 0){
//                        if (relay_st[2][x] != 0x0a){
//                            relay_3 == relay_st[2][x] ?( Index_3 = 0): ((Index_3 = 1),(relay_3 = relay_st[2][x]));
//                        }else{
//                            relay_3 == 0x0c ?( relay_3 = 0x0b): (relay_3 = 0x0c);
//                            Index_3 = 1;
//                        }
//                        if (Index_3 != 0){
//                            relay_msg.data[0] = 0x0a;
//                            relay_msg.data[1] = relay_3;
//                            rt_device_write(can_dev, 0, &relay_msg, sizeof(relay_msg));
//                            MSG_CAN[0] = ID_Number;
//                            rt_mq_send(msg_bk_id, &MSG_CAN, sizeof(MSG_CAN[0]));
//                            MSG_CAN[0] = 0x0a;
//                            rt_mq_send(msg_bk_or, &MSG_CAN, sizeof(MSG_CAN[0]));
//                            MSG_CAN[0] = relay_3;
//                            rt_mq_send(msg_bk_st, &MSG_CAN, sizeof(MSG_CAN[0]));
//                        }
//                    }
//                    bk_light();
//                    light = 0;
//                }
//            }
//        }
//    }
//}
//static void led_back(void *arg)
//{
//    rt_pin_write(FK_PIN[0][1], 0);
//    rt_pin_write(FK_PIN[1][1], 0);
//    rt_pin_write(FK_PIN[2][1], 0);
//    rt_pin_write(FK_PIN[3][1], 0);
//    rt_pin_write(FK_PIN[4][1], 0);
//    rt_pin_write(FK_PIN[5][1], 0);
//    rt_uint8_t or_msg[8],st_msg[8],id_msg[8];
//    while(1)
//    {
//        if(rt_mq_recv(msg_bk_id, &id_msg, sizeof(id_msg), RT_WAITING_FOREVER) == RT_EOK && rt_mq_recv(msg_bk_or, &or_msg, sizeof(or_msg), RT_WAITING_FOREVER) == RT_EOK && rt_mq_recv(msg_bk_st, &st_msg, sizeof(st_msg), RT_WAITING_FOREVER) == RT_EOK)
//        {
//            for (int y = 0; y < 6; y++)
//            {
//               if (bk_off_on[y] == 0x01 && id_msg[0] == bk_id[y] && or_msg[0] == bk_or[y])//
//               {
//                   st_msg[0] == 0x0b ? rt_pin_write(FK_PIN[y][1],1):rt_pin_write(FK_PIN[y][1],0);
//               }
//            }
//        }
//    }
//}
//
//static rt_err_t can_rx_call(rt_device_t dev, rt_size_t size)
//{
//    rt_sem_release(&rx_sem);
//    rt_pin_write(CAN_LED, 1);
//    return RT_EOK;
//}
//static void CAN_Receive(void *arg)
//{
//    struct rt_can_msg rxmsg = {0};
//
//    rt_uint8_t Temporary[1],sp = 0;
//    rt_device_set_rx_indicate(can_dev, can_rx_call);
//
//    while (1)
//    {
//            rxmsg.hdr = -1;
//            rt_sem_take(&rx_sem, RT_WAITING_FOREVER);
//            rt_device_read(can_dev, 0, &rxmsg, sizeof(rxmsg));
//            if (rxmsg.len==1 && rxmsg.ide==0)
//            {
//                MSG_CAN[0] = rxmsg.id;
//                rt_mq_send(msg_id, &MSG_CAN, sizeof(MSG_CAN[0]));
//                MSG_CAN[0] = rxmsg.data[0];
//                rt_mq_send(msg_or, &MSG_CAN, sizeof(MSG_CAN[0]));
//            }else if (rxmsg.len==2 && rxmsg.ide==0)
//            {
//                MSG_CAN[0] = rxmsg.id;
//                rt_mq_send(msg_bk_id, &MSG_CAN, sizeof(MSG_CAN[0]));
//                MSG_CAN[0] = rxmsg.data[0];
//                rt_mq_send(msg_bk_or, &MSG_CAN, sizeof(MSG_CAN[0]));
//                MSG_CAN[0] = rxmsg.data[1];
//                rt_mq_send(msg_bk_st, &MSG_CAN, sizeof(MSG_CAN[0]));
//            }else if (rxmsg.id == (Serial_Number[4]/0x10%0x10)*0x10000000 + (Serial_Number[4]%0x10)*0x1000000 + (Serial_Number[5]/0x10%0x10)*0x100000 + (Serial_Number[5]%0x10)*0x10000 + (Serial_Number[6]/0x10%0x10)*0x1000 + (Serial_Number[6]%0x10)*0x100 + (Serial_Number[7]/0x10%0x10)*0x10+(Serial_Number[7]%0x10)*0x1 && rxmsg.len !=1)
//            {
//                if (rxmsg.len == 6 && rxmsg.data[1] < 0x08)
//                {
//                    //地址
//                    ID_Number = rxmsg.data[0];
//                    key_msg.id = ID_Number;
//                    //脉冲信号或持续信号
//                    short_or_long[rxmsg.data[1]-1] = rxmsg.data[2];
//                    //反馈灯的开启与关闭
//                    bk_off_on[rxmsg.data[1]-1]     = rxmsg.data[3];
//                    //反馈灯id
//                    bk_id[rxmsg.data[1]-1]     = rxmsg.data[4];
//                    //or
//                    bk_or[rxmsg.data[1]-1]     = rxmsg.data[5];
//                }else if (rxmsg.len == 6 && rxmsg.data[1] > 0x07) {
//                    //地址
//                    ID_Number = rxmsg.data[0];
//                    for (int x = 0; x < 20; x++)
//                    {
//                        if (relay_id[rxmsg.data[1]-0x08][x] == 0x00)
//                        {
//                            relay_id[rxmsg.data[1]-0x08][x] = rxmsg.data[2];
//                            //指令
//                            relay_or[rxmsg.data[1]-0x08][x] = rxmsg.data[3];
//                            //更改的状态
//                            relay_st[rxmsg.data[1]-0x08][x] = rxmsg.data[4];
//                            //延时
//                            relay_ys[rxmsg.data[1]-0x08][x] = rxmsg.data[5];
//                            break;
//                        }
//                    }
//                }else if (rxmsg.len == 2)
//                {
//                    if (sp == 0) {
//                        Sleep_id[0] = rxmsg.data[0];
//                        Sleep_or[0] = rxmsg.data[1];
//                        sp++;
//                    } else {
//                        Sleep_id[1] = rxmsg.data[0];
//                        Sleep_or[1] = rxmsg.data[1];
//                    }
//                }
//            }
//            else if (rxmsg.id == (Serial_Number[4]/0x10%0x10)*0x10000000 + (Serial_Number[4]%0x10)*0x1000000 + (Serial_Number[5]/0x10%0x10)*0x100000 + (Serial_Number[5]%0x10)*0x10000 + (Serial_Number[6]/0x10%0x10)*0x1000 + (Serial_Number[6]%0x10)*0x100 + (Serial_Number[7]/0x10%0x10)*0x10+(Serial_Number[7]%0x10)*0x1 && rxmsg.len == 1)
//            {
//                if (rxmsg.data[0]== 0x08)
//                {
//                    rt_pin_write(JDQ_1_K, 1);//继电器动作
//                    rt_thread_mdelay(50);
//                    rt_pin_write(JDQ_1_K, 0);//继电器动作
//                    rt_thread_mdelay(1000);
//                    rt_pin_write(JDQ_1_G, 1);//继电器动作
//                    rt_thread_mdelay(50);
//                    rt_pin_write(JDQ_1_G, 0);//继电器动作
//                }
//                else if(rxmsg.data[0]==0x09)
//                {
//                    rt_pin_write(JDQ_2_K, 1);//继电器动作
//                    rt_thread_mdelay(50);
//                    rt_pin_write(JDQ_2_K, 0);//继电器动作
//                    rt_thread_mdelay(1000);
//                    rt_pin_write(JDQ_2_G, 1);//继电器动作
//                    rt_thread_mdelay(50);
//                    rt_pin_write(JDQ_2_G, 0);//继电器动作
//
//                }
//                else if(rxmsg.data[0]==0x10)
//                {
//                    rt_pin_write(JDQ_3_K, 1);//继电器动作
//                    rt_thread_mdelay(50);
//                    rt_pin_write(JDQ_3_K, 0);//继电器动作
//                    rt_thread_mdelay(1000);
//                    rt_pin_write(JDQ_3_G, 1);//继电器动作
//                    rt_thread_mdelay(50);
//                    rt_pin_write(JDQ_3_G, 0);//继电器动作
//                }
//                else if(rxmsg.data[0]==0x01)
//                {
//                    rt_pin_write(FK_PIN[0][1], 1);
//                    rt_thread_mdelay(1000);
//                    rt_pin_write(FK_PIN[0][1], 0);
//                }
//                else if(rxmsg.data[0]==0x02)
//                {
//                    rt_pin_write(FK_PIN[1][1], 1);
//                    rt_thread_mdelay(1000);
//                    rt_pin_write(FK_PIN[1][1], 0);
//                }
//                else if(rxmsg.data[0]==0x03)
//                {
//                    rt_pin_write(FK_PIN[2][1], 1);
//                    rt_thread_mdelay(1000);
//                    rt_pin_write(FK_PIN[2][1], 0);
//                }
//                else if(rxmsg.data[0]==0x04)
//                {
//                    rt_pin_write(FK_PIN[3][1], 1);
//                    rt_thread_mdelay(1000);
//                    rt_pin_write(FK_PIN[3][1], 0);
//                }
//                else if(rxmsg.data[0]==0x05)
//                {
//                    rt_pin_write(FK_PIN[4][1], 1);
//                    rt_thread_mdelay(1000);
//                    rt_pin_write(FK_PIN[4][1], 0);
//                }
//                else if(rxmsg.data[0]==0x06)
//                {
//                    rt_pin_write(FK_PIN[5][1], 1);
//                    rt_thread_mdelay(1000);
//                    rt_pin_write(FK_PIN[5][1], 0);
//                }
//            }else if (Serial_Number[8]==0xff && rxmsg.id == 0x00 && rxmsg.len==8 )  //
//            {
//                rt_enter_critical();
//                stm32_flash_erase(Serial_Number_adder, 30);
//                for (int i = 0; i < rxmsg.len; i++)
//                {
//                    Temporary[0] = rxmsg.data[i];
//                    stm32_flash_write(Serial_Number_adder+(i*4), Temporary, 1);
//                }
//                rt_exit_critical();
//                __set_FAULTMASK(1);
//                NVIC_SystemReset();
//            }else if (rxmsg.id == 0x00 && rxmsg.ide == 1 && rxmsg.data[0]==0xff && rxmsg.data[1]==0xff)
//            {
//                //
//                rt_enter_critical();
//                //id
//                Temporary[0] = ID_Number;
//                stm32_flash_write(CAN_ID_Number_adder, Temporary, 1);
//                //seelp
//                Temporary[0] = Sleep_id[0];
//                stm32_flash_write(seelp_id_adder, Temporary, 1);
//                Temporary[0] = Sleep_id[1];
//                stm32_flash_write(seelp_id_adder+4, Temporary, 1);
//                Temporary[0] = Sleep_or[0];
//                stm32_flash_write(seelp_or_adder, Temporary, 1);
//                Temporary[0] = Sleep_or[1];
//                stm32_flash_write(seelp_or_adder+4, Temporary, 1);
//                //short_or_long
//                //back_led_kg_adder
//                //back_led_id_adder
//                for (int tem = 0; tem < 7; tem++)
//                {
//                    Temporary[0] = short_or_long[tem];
//                    stm32_flash_write(long_and_short_adder+ (tem * 4), Temporary, 1);
//                    Temporary[0] = bk_off_on[tem];
//                    stm32_flash_write(back_led_kg_adder+ (tem * 4), Temporary, 1);
//                    Temporary[0] = bk_id[tem];
//                    stm32_flash_write(back_led_id_adder+ (tem * 4), Temporary, 1);
//                    Temporary[0] = bk_or[tem];
//                    stm32_flash_write(back_led_or_adder+ (tem * 4), Temporary, 1);
//                }
//                for (int var = 0; var < 4; var++)
//                {
//                    for (int tem = 0; tem < 20; tem++)
//                    {
//                        Temporary[0] = relay_id[var][tem];
//                        stm32_flash_write(relay_id_adder+ (var*40)+(tem * 4), Temporary, 1);
//                        Temporary[0] = relay_or[var][tem];
//                        stm32_flash_write(relay_or_adder+ (var*40)+(tem * 4), Temporary, 1);
//                        Temporary[0] = relay_st[var][tem];
//                        stm32_flash_write(relay_st_adder+ (var*40)+(tem * 4), Temporary, 1);
//                        Temporary[0] = relay_ys[var][tem];
//                        stm32_flash_write(relay_ys_adder+ (var*40)+(tem * 4), Temporary, 1);
//                    }
//                }
//                rt_exit_critical();
//                //
//                __set_FAULTMASK(1);
//                NVIC_SystemReset();
//            }else if (rxmsg.id == 0x00 && rxmsg.ide == 1 && rxmsg.data[0]==0xfe && rxmsg.data[1]==0xfe)
//            {
//                rt_enter_critical();
//                memset(relay_id, 0, sizeof(relay_id));
//                memset(relay_or, 0, sizeof(relay_or));
//                memset(Sleep_id, 0, sizeof(Sleep_id));
//                memset(Sleep_or, 0, sizeof(Sleep_or));
//                stm32_flash_erase(FLAG_FLASH, 2048);
//                rt_exit_critical();
//            }else if (rxmsg.id == 0x00 && rxmsg.ide == 1 && rxmsg.data[0]==0xff && rxmsg.data[1]==0xfe)
//            {
//                rxmsg.id = (Serial_Number[4]/0x10%0x10)*0x10000000 + (Serial_Number[4]%0x10)*0x1000000 + (Serial_Number[5]/0x10%0x10)*0x100000 + (Serial_Number[5]%0x10)*0x10000 + (Serial_Number[6]/0x10%0x10)*0x1000 + (Serial_Number[6]%0x10)*0x100 + (Serial_Number[7]/0x10%0x10)*0x10+(Serial_Number[7]%0x10)*0x1;
//                rxmsg.ide=1;
//                rxmsg.len=8;
//                rxmsg.data[0] = Serial_Number[0];
//                rxmsg.data[1] = Serial_Number[1];
//                rxmsg.data[2] = Serial_Number[2];
//                rxmsg.data[3] = Serial_Number[3];
//                rxmsg.data[4] = Serial_Number[4];
//                rxmsg.data[5] = Serial_Number[5];
//                rxmsg.data[6] = Serial_Number[6];
//                rxmsg.data[7] = Serial_Number[7];
//                rt_device_write(can_dev, 0, &rxmsg, sizeof(rxmsg));
//            }
//            rt_pin_write(CAN_LED, 0);
//        }
//}
//static uint8_t button_key0_read(void)
//{
//    return rt_pin_read(PIN_KEY0);
//}
//
//static uint8_t button_key1_read(void)
//{
//    return rt_pin_read(PIN_KEY1);
//}
//static uint8_t button_key2_read(void)
//{
//    return rt_pin_read(PIN_KEY2);
//}
//static uint8_t button_key3_read(void)
//{
//    return rt_pin_read(PIN_KEY3);
//}
//static uint8_t button_key4_read(void)
//{
//    return rt_pin_read(PIN_KEY4);
//}
//static uint8_t button_key5_read(void)
//{
//    return rt_pin_read(PIN_KEY5);
//}
//static uint8_t button_key6_read(void)
//{
//    return rt_pin_read(PIN_KEY6);
//}
//static void user_button_init(void)
//{
//    int i;
//    FK_PIN[0][1] = 45;FK_PIN[1][1] = 23;FK_PIN[2][1] = 22;FK_PIN[3][1] = 21;FK_PIN[4][1] = 20;FK_PIN[5][1] = 19;FK_PIN[6][1] = 15;
//    rt_pin_mode(PIN_KEY0, PIN_MODE_INPUT_PULLUP ); rt_pin_mode(PIN_KEY1, PIN_MODE_INPUT_PULLUP );
//    rt_pin_mode(PIN_KEY2, PIN_MODE_INPUT_PULLUP ); rt_pin_mode(PIN_KEY3, PIN_MODE_INPUT_PULLUP );
//    rt_pin_mode(PIN_KEY4, PIN_MODE_INPUT_PULLUP ); rt_pin_mode(PIN_KEY5, PIN_MODE_INPUT_PULLUP );
//    rt_pin_mode(PIN_KEY6, PIN_MODE_INPUT_PULLUP );
//
//    rt_pin_mode(CAN_LED, PIN_MODE_OUTPUT);rt_pin_write(CAN_LED, 0);
//    rt_pin_mode(FK_PIN[0][1], PIN_MODE_OUTPUT);    FK_PIN[0][0] = 0x01;rt_pin_write(FK_PIN[0][1], 0);
//    rt_pin_mode(FK_PIN[1][1], PIN_MODE_OUTPUT);    FK_PIN[1][0] = 0x01;rt_pin_write(FK_PIN[1][1], 0);
//    rt_pin_mode(FK_PIN[2][1], PIN_MODE_OUTPUT);    FK_PIN[2][0] = 0x01;rt_pin_write(FK_PIN[2][1], 0);
//    rt_pin_mode(FK_PIN[3][1], PIN_MODE_OUTPUT);    FK_PIN[3][0] = 0x01;rt_pin_write(FK_PIN[3][1], 0);
//    rt_pin_mode(FK_PIN[4][1], PIN_MODE_OUTPUT);    FK_PIN[4][0] = 0x01;rt_pin_write(FK_PIN[4][1], 0);
//    rt_pin_mode(FK_PIN[5][1], PIN_MODE_OUTPUT);    FK_PIN[5][0] = 0x01;rt_pin_write(FK_PIN[5][1], 0);
//    rt_pin_mode(FK_PIN[6][1], PIN_MODE_OUTPUT);    FK_PIN[6][0] = 0x01;rt_pin_write(FK_PIN[6][1], 1);
//
//    rt_pin_mode(JDQ_1_K, PIN_MODE_OUTPUT);rt_pin_write(JDQ_1_K, 0);
//    rt_pin_mode(JDQ_1_G, PIN_MODE_OUTPUT);rt_pin_write(JDQ_1_G, 1);
//    rt_pin_mode(JDQ_2_K, PIN_MODE_OUTPUT);rt_pin_write(JDQ_2_K, 0);
//    rt_pin_mode(JDQ_2_G, PIN_MODE_OUTPUT);rt_pin_write(JDQ_2_G, 1);
//    rt_pin_mode(JDQ_3_K, PIN_MODE_OUTPUT);rt_pin_write(JDQ_3_K, 0);
//    rt_pin_mode(JDQ_3_G, PIN_MODE_OUTPUT);rt_pin_write(JDQ_3_G, 1);
//    rt_thread_mdelay(45);
//    rt_pin_write(JDQ_1_G, 0);
//    rt_pin_write(JDQ_2_G, 0);
//    rt_pin_write(JDQ_3_G, 0);
//
//    rt_memset(&user_button[0], 0x0, sizeof(user_button));
//    //
//    user_button[USER_BUTTON_0].usr_button_read = button_key0_read;
//    user_button[USER_BUTTON_0].cb = (flex_button_response_callback)btn_0_cb;
//    //
//    user_button[USER_BUTTON_1].usr_button_read = button_key1_read;
//    user_button[USER_BUTTON_1].cb = (flex_button_response_callback)btn_1_cb;
//    //
//    user_button[USER_BUTTON_2].usr_button_read = button_key2_read;
//    user_button[USER_BUTTON_2].cb = (flex_button_response_callback)btn_2_cb;
//    //
//    user_button[USER_BUTTON_3].usr_button_read = button_key3_read;
//    user_button[USER_BUTTON_3].cb = (flex_button_response_callback)btn_3_cb;
//    //
//    user_button[USER_BUTTON_4].usr_button_read = button_key4_read;
//    user_button[USER_BUTTON_4].cb = (flex_button_response_callback)btn_4_cb;
//    //
//    user_button[USER_BUTTON_5].usr_button_read = button_key5_read;
//    user_button[USER_BUTTON_5].cb = (flex_button_response_callback)btn_5_cb;
//    //
//    user_button[USER_BUTTON_6].usr_button_read = button_key6_read;
//    user_button[USER_BUTTON_6].cb = (flex_button_response_callback)btn_6_cb;
//    for (i = 0; i < USER_BUTTON_MAX; i ++)
//    {
//        user_button[i].pressed_logic_level = 0;
//        user_button[i].click_start_tick = 15;
//        user_button[i].short_press_start_tick = 0;
//        user_button[i].long_press_start_tick =  25;
//        user_button[i].long_hold_start_tick = 30;
//        flex_button_register(&user_button[i]);
//    }
//}
//int flex_button_main(void)
//{
//    rt_uint8_t size[1];
//    rt_thread_t Butt_thread = RT_NULL;
//    rt_thread_t Relay_A1    = RT_NULL;
//    rt_thread_t Relay_A2    = RT_NULL;
//    rt_thread_t Relay_A3    = RT_NULL;
//    rt_thread_t Relay_A4    = RT_NULL;
//    rt_thread_t Back    = RT_NULL;
//    rt_thread_t Order   = RT_NULL;
//
//    char can_name[RT_NAME_MAX];
//
//    rt_strncpy(can_name, CAN_DEV_NAME, RT_NAME_MAX);
//
//    can_dev = rt_device_find(can_name);
//
//    rt_sem_init(&rx_sem,     "rx_sem", 0, RT_IPC_FLAG_FIFO);
//
//    rt_device_open(can_dev, RT_DEVICE_FLAG_INT_RX|RT_DEVICE_FLAG_INT_TX);
//
//    Serial_Number[8]=0x1f;
//    //输出发送的指令
//    Serial_Number[0] = 0x20;Serial_Number[1] = 0x04;Serial_Number[2] = 0x22;Serial_Number[3] = 0x12;
//    Serial_Number[4] = 0x00;Serial_Number[5] = 0x00;Serial_Number[6] = 0x00;Serial_Number[7] = 0x02;
////    stm32_flash_read(Serial_Number_adder,     size, 1);Serial_Number[0] = size[0];
////    stm32_flash_read(Serial_Number_adder+4,   size, 1);Serial_Number[1] = size[0];
////    stm32_flash_read(Serial_Number_adder+8,   size, 1);Serial_Number[2] = size[0];
////    stm32_flash_read(Serial_Number_adder+12,  size, 1);Serial_Number[3] = size[0];
////    stm32_flash_read(Serial_Number_adder+16,  size, 1);Serial_Number[4] = size[0];
////    stm32_flash_read(Serial_Number_adder+20,  size, 1);Serial_Number[5] = size[0];
////    stm32_flash_read(Serial_Number_adder+24,  size, 1);Serial_Number[6] = size[0];
////    stm32_flash_read(Serial_Number_adder+28,  size, 1);Serial_Number[7] = size[0];
//    if (Serial_Number[0] != 0)
//    {
//            user_button_init();
//            //CAN_ID
//            rt_thread_delay(100);
//            rt_enter_critical();
//            stm32_flash_read(CAN_ID_Number_adder,    size, 1);ID_Number = size[0];
//            //
//            stm32_flash_read(seelp_id_adder,    size, 1);  Sleep_id[0] = size[0];
//            stm32_flash_read(seelp_id_adder+4,    size, 1);Sleep_id[1] = size[0];
//            stm32_flash_read(seelp_or_adder,    size, 1);  Sleep_or[0] = size[0];
//            stm32_flash_read(seelp_or_adder+4,    size, 1);Sleep_or[1] = size[0];
//            //short_or_long
//            //back_led_kg_adder
//            //back_led_id_adder
//            for (int tem = 0; tem < 7; tem++)
//            {
//                stm32_flash_read(long_and_short_adder+ (tem * 4),    size, 1);short_or_long[tem] = size[0];
//                stm32_flash_read(back_led_kg_adder+ (tem * 4),    size, 1);   bk_off_on[tem] = size[0];
//                stm32_flash_read(back_led_id_adder+ (tem * 4),    size, 1);   bk_id[tem] = size[0];
//                stm32_flash_read(back_led_or_adder+ (tem * 4),    size, 1);   bk_or[tem] = size[0];
//
//            }
//            for (int var = 0; var < 4; var++)
//            {
//               for (int tem = 0; tem < 20; tem++)
//               {
//                   stm32_flash_read(relay_id_adder+ (var*40)+(tem * 4),    size, 1);relay_id[var][tem] = size[0];
//                   stm32_flash_read(relay_or_adder+ (var*40)+(tem * 4),    size, 1);relay_or[var][tem] = size[0];
//                   stm32_flash_read(relay_st_adder+ (var*40)+(tem * 4),    size, 1);relay_st[var][tem] = size[0];
//                   stm32_flash_read(relay_ys_adder+ (var*40)+(tem * 4),    size, 1);relay_ys[var][tem] = size[0];
//               }
//            }
//        rt_exit_critical();
//        Butt_thread = rt_thread_create("butt", button_scan, RT_NULL, 800, 7, 5);
//        Relay_A1    = rt_thread_create("pwm_1", relay_puls_1, RT_NULL, 500, 6, 5);
//        Relay_A2    = rt_thread_create("pwm_2", relay_puls_2, RT_NULL, 500, 6, 5);
//        Relay_A3    = rt_thread_create("pwm_3", relay_puls_3, RT_NULL, 500, 6, 5);
//
//        Back        = rt_thread_create("BACK", led_back, RT_NULL, 1000, 7, 5);
//        Order       = rt_thread_create("ORDER", pwm_order, RT_NULL, 1000, 7, 5);
//
//        //信号队列
//        msg_bk_id = rt_mq_create("bk_id",2,50,RT_IPC_FLAG_FIFO);
//        msg_bk_st = rt_mq_create("bk_st",2,50,RT_IPC_FLAG_FIFO);
//        msg_bk_or = rt_mq_create("bk_or",2,50,RT_IPC_FLAG_FIFO);
//
//
//        msg_id = rt_mq_create("id",2,50,RT_IPC_FLAG_FIFO);
//        msg_or = rt_mq_create("or",2,50,RT_IPC_FLAG_FIFO);
//        msg_st = rt_mq_create("st",2,50,RT_IPC_FLAG_FIFO);
//
//
//        rt_thread_startup(Butt_thread);
//        rt_thread_startup(Relay_A1);
//        rt_thread_startup(Relay_A2);
//        rt_thread_startup(Relay_A3);
//        rt_thread_startup(Relay_A4);
//        rt_thread_startup(Back);
//        rt_thread_startup(Order);
//        hwtimer_sample();
//    }else {
//        Serial_Number[8] = 0xff;
//    }
//    rt_thread_init(&CAN_Thread, "rx_can", CAN_Receive, RT_NULL, CAN_thread_stack, 800, 6, 10);
//    rt_thread_startup(&CAN_Thread);
//    key_msg.id = ID_Number;
//    key_msg.len= 1;
//    key_msg.ide= 0;
//    relay_msg.id = ID_Number;
//    relay_msg.len= 2;
//    relay_msg.ide= 0;
//    return 0;
//}
