//#include <rtthread.h>
//#include "flexible_button.h"
//#include <stdint.h>
//#include <stdlib.h>
//#include <rtdevice.h>
//#include <board.h>
//#include "DeviceGeneral.h"
//struct Time time;
//struct Relay Relay;
//struct Break Break;
//struct Butt  Butt;
//
//#define WDT_DEVICE_NAME    "wdt"    /* 看门狗设备名称 */
//
//static rt_device_t wdg_dev;         /* 看门狗设备句柄 */
//
//static void idle_hook(void)
//{
//    /* 在空闲线程的回调函数里喂狗 */
//    rt_device_control(wdg_dev, RT_DEVICE_CTRL_WDT_KEEPALIVE, NULL);
//    rt_kprintf("feed the dog!\n ");
//}
//static void timeout(void *parameter)
//{
//
//    if (time.index++ == 30)//10次停止
//    {
//        if (Relay.times[0] == 1)       { //判断第一个是否进入计时模式
//
//            Relay.times[0] = 1;
//            Relay.To_Flag[0] = 1;
//            Relay.To_state[0] = 0x0c;
//
//        }else if (Relay.times[1] == 1) { //判断第一个是否进入计时模式
//
//            Relay.times[1] = 1;
//            Relay.To_Flag[1] = 1;
//            Relay.To_state[1] = 0x0c;
//
//        }else if (Relay.times[2] == 1) { //判断第一个是否进入计时模式
//
//            Relay.times[2] = 1;
//            Relay.To_Flag[2] = 1;
//            Relay.To_state[2] = 0x0c;
//
//        }else if (Relay.times[3] == 1) { //判断第一个是否进入计时模式
//
//            Relay.times[3] = 1;
//            Relay.To_Flag[3] = 1;
//            Relay.To_state[3] = 0x0c;
//
//        }
//        time.index = 0;
//        rt_timer_stop(timer);
//
//    }else if(time.index > 30){          //如果索引大于30 退出睡眠模式
//
//        rt_timer_stop(timer);
//
//        Relay.times[0] = 0;
//        Relay.times[1] = 0;
//        Relay.times[2] = 0;
//        Relay.times[3] = 0;
//
//        Relay.To_Flag[0] = 0;
//        Relay.To_Flag[1] = 0;
//        Relay.To_Flag[2] = 0;
//        Relay.To_Flag[3] = 0;
//        time.index = 0;
//    }
//}
//
//static void Sleep(void *parameter)
//{
//    if (time.Seelp++ == 9)//10次停止
//    {
//        rt_pin_write(Break.LED[6], 0);  //背景光关闭
//
//        rt_timer_stop(sleep);
//        time.Seelp = 0;
//
//    }else if(time.Seelp > 9){
//
//        rt_pin_write(Break.LED[6], 0);  //背景光开启
//        rt_timer_stop(sleep);
//        time.Seelp = 0;
//    }
//}
//
////创建定时器
//void hwtimer_sample(void)
//{
//    timer = rt_timer_create("timer", timeout,RT_NULL, 1000, RT_TIMER_FLAG_PERIODIC);
//    sleep = rt_timer_create("sleep", Sleep,  RT_NULL, 1000, RT_TIMER_FLAG_PERIODIC);
//}
//
//void butt_send_msg(rt_uint8_t index)
//{
//
//    butt.id = ID_Number;
//    butt.ide= 0;
//    butt.len= 1;
//    if (Break.it_id[index] == 0xff)
//    {
//
//        butt.data[0] = 0xff;
//        rt_device_write(can_dev, 0, &butt, sizeof(butt)); //向CAN总线发送全关指令
//
//        tem_sem[0] = ID_Number;
//        rt_mq_send(msg_id, &tem_sem, sizeof(tem_sem[0])); //向消息队列发送ID
//
//        tem_sem[0] = 0xff;
//        rt_mq_send(msg_or, &tem_sem, sizeof(tem_sem[0])); //向消息队列发送指令
//
//    } else {
//
//        butt.data[0] = index+1;
//        rt_device_write(can_dev, 0, &butt, sizeof(butt)); //向CAN总线发送指令
//
//        tem_sem[0] = ID_Number;
//        rt_mq_send(msg_id, &tem_sem, sizeof(tem_sem[0]));
//
//        tem_sem[0] = index+1;
//        rt_mq_send(msg_or, &tem_sem, sizeof(tem_sem[0]));
//    }
//}
////按键1
//static void btn_0_cb(flex_button_t *btn)
//{
//    if (btn->event==FLEX_BTN_PRESS_DOWN && Butt.short_long[0] == 1)
//    {
//        butt_send_msg(0);
//
//    }else if (btn->event==FLEX_BTN_PRESS_LONG_HOLD && Butt.short_long[0] == 2) {
//
//        butt_send_msg(0);
//
//    }else if (btn->event==FLEX_BTN_PRESS_LONG_HOLD_UP && Butt.short_long[0] == 2)
//    {
//        butt_send_msg(0);
//
//    }else if (btn->event==FLEX_BTN_PRESS_DOWN && Butt.short_long[0] == 0xff){
//
//        Relay.To_Flag[0] = 1;
//        Relay.To_state[0] == 0x0b ? ((Relay.To_state[0] = 0x0c),(rt_pin_write(Break.LED[0], 0))) : ((Relay.To_state[0] = 0x0b),(rt_pin_write(Break.LED[0], 1)));
//
//    }
//}
////按键2
//static void btn_1_cb(flex_button_t *btn)
//{
//    if (btn->event==FLEX_BTN_PRESS_DOWN && Butt.short_long[1] == 1)
//    {
//
//        butt_send_msg(1);
//
//    }else if (btn->event==FLEX_BTN_PRESS_LONG_HOLD && Butt.short_long[1] == 2) {
//
//        butt_send_msg(1);
//
//    }else if (btn->event==FLEX_BTN_PRESS_LONG_HOLD_UP && Butt.short_long[1] == 2)
//    {
//
//        butt_send_msg(1);
//
//    }else if (btn->event==FLEX_BTN_PRESS_DOWN && Butt.short_long[1] == 0xff){
//
//        Relay.To_Flag[1] = 1;
//        Relay.To_state[1] == 0x0b ? ((Relay.To_state[1] = 0x0c),(rt_pin_write(Break.LED[1], 0))) : ((Relay.To_state[1] = 0x0b),(rt_pin_write(Break.LED[1], 1)));
//
//    }
//}
////按键3
//static void btn_2_cb(flex_button_t *btn)
//{
//    if (btn->event==FLEX_BTN_PRESS_DOWN && Butt.short_long[2] == 1)
//    {
//        butt_send_msg(2);
//
//    }else if (btn->event==FLEX_BTN_PRESS_LONG_HOLD && Butt.short_long[2] == 2)
//    {
//        butt_send_msg(2);
//
//    }else if (btn->event==FLEX_BTN_PRESS_LONG_HOLD_UP && Butt.short_long[2] == 2)
//    {
//        butt_send_msg(2);
//
//    }else if (btn->event==FLEX_BTN_PRESS_DOWN && Butt.short_long[2] == 0xff){
//
//        Relay.To_Flag[2] = 1;
//        Relay.To_state[2] == 0x0b ? ((Relay.To_state[2] = 0x0c),(rt_pin_write(Break.LED[2], 0))) : ((Relay.To_state[2] = 0x0b),(rt_pin_write(Break.LED[2], 1)));
//
//    }
//}
////按键4
//static void btn_3_cb(flex_button_t *btn)
//{
//    if (btn->event==FLEX_BTN_PRESS_DOWN && Butt.short_long[3] == 1)
//    {
//
//        butt_send_msg(3);
//
//    }else if (btn->event==FLEX_BTN_PRESS_LONG_HOLD && Butt.short_long[3] == 2)
//    {
//
//        butt_send_msg(3);
//
//    }else if (btn->event==FLEX_BTN_PRESS_LONG_HOLD_UP && Butt.short_long[3] == 2)
//    {
//
//        butt_send_msg(3);
//
//    }else if (btn->event==FLEX_BTN_PRESS_DOWN && Butt.short_long[3] == 0xff){
//
//        Relay.To_Flag[3] = 1;
//        Relay.To_state[3] == 0x0b ? ((Relay.To_state[3] = 0x0c),(rt_pin_write(Break.LED[3], 0))) : ((Relay.To_state[3] = 0x0b),(rt_pin_write(Break.LED[3], 1)));
//
//    }
//}
////按键5
//static void btn_4_cb(flex_button_t *btn)
//{
//    if (btn->event==FLEX_BTN_PRESS_DOWN && Butt.short_long[4] == 1)
//    {
//
//        butt_send_msg(4);
//
//    }else if (btn->event==FLEX_BTN_PRESS_LONG_HOLD && Butt.short_long[4] == 2)
//    {
//
//        butt_send_msg(4);
//
//    }else if (btn->event==FLEX_BTN_PRESS_LONG_HOLD_UP && Butt.short_long[4] == 2)
//    {
//
//        butt_send_msg(4);
//
//    }else if (btn->event==FLEX_BTN_PRESS_DOWN && Butt.short_long[4] == 0xff){
//
//        Relay.To_Flag[0] = Relay.To_Flag[1] = Relay.To_Flag[2] = Relay.To_Flag[3] = 1;
//        Relay.To_state[0] = Relay.To_state[1] = Relay.To_state[2] = Relay.To_state[3] = 0x0b;
//        rt_pin_write(Break.LED[0], 1);
//        rt_pin_write(Break.LED[1], 1);
//        rt_pin_write(Break.LED[2], 1);
//        rt_pin_write(Break.LED[3], 1);
//
//    }
//}
////按键6
//static void btn_5_cb(flex_button_t *btn)
//{
//    if (btn->event==FLEX_BTN_PRESS_DOWN && Butt.short_long[5] == 1)
//    {
//
//        butt_send_msg(5);
//
//    }else if (btn->event==FLEX_BTN_PRESS_LONG_HOLD && Butt.short_long[5] == 2)
//    {
//
//        butt_send_msg(5);
//
//    }else if (btn->event==FLEX_BTN_PRESS_LONG_HOLD_UP && Butt.short_long[5] == 2)
//    {
//
//        butt_send_msg(5);
//
//    }else if (btn->event==FLEX_BTN_PRESS_DOWN && Butt.short_long[5] == 0xff){
//
//        Relay.To_Flag[0] = Relay.To_Flag[1] = Relay.To_Flag[2] = Relay.To_Flag[3] = 1;
//        Relay.To_state[0] = Relay.To_state[1] = Relay.To_state[2] = Relay.To_state[3] = 0x0c;
//        rt_pin_write(Break.LED[0], 0);
//        rt_pin_write(Break.LED[1], 0);
//        rt_pin_write(Break.LED[2], 0);
//        rt_pin_write(Break.LED[3], 0);
//    }
//}
////按键7
//static void btn_6_cb(flex_button_t *btn)
//{
//    if (btn->event==FLEX_BTN_PRESS_DOWN && Butt.short_long[6] == 1)
//    {
//
//        butt_send_msg(6);
//
//    }else if (btn->event==FLEX_BTN_PRESS_LONG_HOLD && Butt.short_long[6] == 2)
//    {
//
//        butt_send_msg(6);
//
//    }else if (btn->event==FLEX_BTN_PRESS_LONG_HOLD_UP && Butt.short_long[6] == 2)
//    {
//
//        butt_send_msg(6);
//
//    }
//}
//static void button_scan(void *arg)
//{
//    while(1)
//    {
//        flex_button_scan();
//        rt_thread_mdelay(10);
//    }
//}
//static void Relay_puls_1(void *arg)
//{
//    while(1)
//    {
//        if(Relay.To_Flag[0] != 0)
//        {
//            if (Relay.To_state[0] == 0x0b) {
//                rt_pin_write(Relay.To_Relay[0], 1);//继电器动作
//            }else {
//                rt_pin_write(Relay.To_Relay[0], 0);//继电器动作
//            }
//            Relay.To_Flag[0] = 0;
//        }
//        rt_thread_mdelay(1);
//    }
//}
//static void Relay_puls_2(void *arg)
//{
//    while(1)
//    {
//        if(Relay.To_Flag[1] != 0)
//        {
//            if (Relay.To_state[1] == 0x0b) {
//                rt_pin_write(Relay.To_Relay[1], 1);//继电器动作
//            }else {
//                rt_pin_write(Relay.To_Relay[1], 0);//继电器动作
//            }
//            Relay.To_Flag[1] = 0;
//        }
//        rt_thread_mdelay(1);
//    }
//}
//static void Relay_puls_3(void *arg)
//{
//    while(1)
//    {
//        if(Relay.To_Flag[2] != 0)
//        {
//            if (Relay.To_state[2] == 0x0b) {
//                rt_pin_write(Relay.To_Relay[2], 1);//继电器动作
//            }else {
//                rt_pin_write(Relay.To_Relay[2], 0);//继电器动作
//            }
//            Relay.To_Flag[2] = 0;
//        }
//        rt_thread_mdelay(1);
//    }
//}
//static void Relay_puls_4(void *arg)
//{
//    while(1)
//    {
//        if(Relay.To_Flag[3] != 0)
//        {
//            if (Relay.To_state[3] == 0x0b) {
//                rt_pin_write(Relay.To_Relay[3], 1);//继电器动作
//            }else {
//                rt_pin_write(Relay.To_Relay[3], 0);//继电器动作
//            }
//            Relay.To_Flag[3] = 0;
//        }
//        rt_thread_mdelay(1);
//    }
//}
//
//void Sleep_off(rt_uint8_t or)
//{
//    rt_pin_write(Break.LED[0], 0);          //全关和睡眠指令,所有反馈灯关闭
//    rt_pin_write(Break.LED[1], 0);
//    rt_pin_write(Break.LED[2], 0);
//    rt_pin_write(Break.LED[3], 0);
//    rt_pin_write(Break.LED[4], 0);
//    rt_pin_write(Break.LED[5], 0);
//
//    if (or != 0xff) {                       //睡眠指令
//        if (light == 0) {                   //第一次按下睡眠
//
//            time.Seelp = 0;
//            Relay.To_state[0] = 0x0c;       //本模块的输出关闭
//            Relay.To_state[1] = 0x0c;
//            Relay.To_state[2] = 0x0c;
//            Relay.To_state[3] = 0x0c;
//
//            Relay.To_Flag[0] = 1;           //
//            Relay.To_Flag[1] = 1;
//            Relay.To_Flag[2] = 1;
//            Relay.To_Flag[3] = 1;
//
//            rt_timer_start(sleep);          //进入倒计时10秒关闭背景光
//            light++;                        //
//
//        }else {                             //第二次按下睡眠,背景光打开
//
//            time.Seelp = 10;
//            rt_pin_write(Break.LED[6], 1);
//            light = 0;
//
//        }
//    }else {                                 //全关指令
//        Relay.To_state[0] = 0x0c;           //都先写入关闭指令
//        Relay.To_state[1] = 0x0c;
//        Relay.To_state[2] = 0x0c;
//        Relay.To_state[3] = 0x0c;
//
//        all = 1;
//    }
//}
//static void pwm_order(void *arg)
//{
//    rt_uint8_t id_m[8],or_m[8];
//    struct rt_can_msg Send_order = {0};
//    Send_order.id = ID_Number;
//    Send_order.len= 2;
//    Send_order.ide= 0;
//    while(1)
//    {
//        if(rt_mq_recv(msg_id, &id_m, sizeof(id_m), RT_WAITING_FOREVER) == RT_EOK && rt_mq_recv(msg_or, &or_m, sizeof(or_m), RT_WAITING_FOREVER) == RT_EOK)
//        {
//
//            light = 0;
//            time.Seelp = 10;
//            rt_pin_write(Break.LED[6], 1);
//
//            if (or_m[0] == 0xff || (id_m[0] == Sleep_id[0] && or_m[0]== Sleep_or[0]) || (id_m[0] == Sleep_id[1] && or_m[0]== Sleep_or[1]))
//            {
//                Sleep_off(or_m[0]);
//            }
//            for (int y = 0; y < 4; y++)
//            {
//                for (int x = 0; x < 10; x++)
//                {
//                    if (id_m[0] == Relay.Sava_id[y][x] && or_m[0] == Relay.Sava_order[y][x])
//                    {
//                        if (or_m[0] == 0xff)    //接收的是全关指令
//                        {
//
//                            rt_timer_start(timer);
//                            if (Relay.Sava_state[y][x] == 0x0a){  //继电器全关,如果是开关的接收延时30秒关闭
//
//                                Relay.To_state[y] = 0x0b;
//                                Relay.To_Flag[y]  = 1;
//                                Relay.times[y]    = 1;
//                            }else{
//
//                                Relay.To_state[y] = Relay.Sava_state[y][x]; //继电器全关,如果是只开的就不关闭
//                                Relay.To_Flag[y]  = 1;
//
//                            }
//
//                        }else if(light == 0){
//
//                            if (Relay.Sava_state[y][x] != 0x0a){    //不等于0x0a的
//
//                                Relay.To_state[y] == Relay.Sava_state[y][x] ?(Relay.To_Flag[y] = 0): ((Relay.To_Flag[y] = 1),(Relay.To_state[y] = Relay.Sava_state[y][x]));
//
//                            }else{
//
//                                Relay.To_state[y] == 0x0c ?(Relay.To_state[y] = 0x0b): (Relay.To_state[y] = 0x0c);
//                                Relay.To_Flag[y] = 1;
//
//                            }
//                            if (Relay.To_Flag[y] != 0){            //不动作的就不发送反馈出去
//
//                                Send_order.data[0] = 8 + y;
//                                Send_order.data[1] = Relay.To_state[y];
//                                rt_device_write(can_dev, 0, &Send_order, sizeof(Send_order));
//
//                                tem_sem[0] = ID_Number;
//                                rt_mq_send(msg_bk_id, &tem_sem, sizeof(tem_sem[0]));
//
//                                tem_sem[0] = 8 + y;
//                                rt_mq_send(msg_bk_or, &tem_sem, sizeof(tem_sem[0]));
//
//                                tem_sem[0] = Relay.To_state[y];
//                                rt_mq_send(msg_bk_st, &tem_sem, sizeof(tem_sem[0]));
//
//                            }
//                        }
//                    }
//                }
//            }
//            if (all == 1) {
//                Relay.To_Flag[0] = 1;
//                Relay.To_Flag[1] = 1;
//                Relay.To_Flag[2] = 1;
//                Relay.To_Flag[3] = 1;
//            }
//        }
//    }
//}
//static void led_back(void *arg)
//{
//    rt_uint8_t or_msg[8],st_msg[8],id_msg[8];
//    while(1)
//    {
//        if(rt_mq_recv(msg_bk_id, &id_msg, sizeof(id_msg), RT_WAITING_FOREVER) == RT_EOK && rt_mq_recv(msg_bk_or, &or_msg, sizeof(or_msg), RT_WAITING_FOREVER) == RT_EOK && rt_mq_recv(msg_bk_st, &st_msg, sizeof(st_msg), RT_WAITING_FOREVER) == RT_EOK)
//        {
//            for (int y = 0; y < 6; y++)
//            {
//               if (Break.on_off[y] == 0x01 && id_msg[0] == Break.it_id[y] && or_msg[0] == Break.it_state[y])//
//               {
//                   st_msg[0] == 0x0b ? rt_pin_write(Break.LED[y],1):rt_pin_write(Break.LED[y],0);
//               }
//            }
//        }
//    }
//}
//
//static rt_err_t can_rx_call(rt_device_t dev, rt_size_t size)
//{
//    rt_sem_release(&rx_sem);
//    rt_pin_write(CAN_LED, 1);
//    return RT_EOK;
//}
//static void CAN_Receive(void *arg)
//{
//    struct rt_can_msg rxmsg = {0};
//
//    rt_uint8_t Temporary[1],sp = 0;
//    rt_device_set_rx_indicate(can_dev, can_rx_call);
//
//    while (1)
//    {
//            rxmsg.hdr = -1;
//            rt_sem_take(&rx_sem, RT_WAITING_FOREVER);
//            rt_device_read(can_dev, 0, &rxmsg, sizeof(rxmsg));
//            if (rxmsg.len==1 && rxmsg.ide==0)
//            {
//
//                tem_sem[0] = rxmsg.id;
//                rt_mq_send(msg_id, &tem_sem, sizeof(tem_sem[0]));
//                tem_sem[0] = rxmsg.data[0];
//                rt_mq_send(msg_or, &tem_sem, sizeof(tem_sem[0]));
//
//            }else if (rxmsg.len==2 && rxmsg.ide==0)
//            {
//
//                tem_sem[0] = rxmsg.id;
//                rt_mq_send(msg_bk_id, &tem_sem, sizeof(tem_sem[0]));
//                tem_sem[0] = rxmsg.data[0];
//                rt_mq_send(msg_bk_or, &tem_sem, sizeof(tem_sem[0]));
//                tem_sem[0] = rxmsg.data[1];
//                rt_mq_send(msg_bk_st, &tem_sem, sizeof(tem_sem[0]));
//
//            }else if (rxmsg.id == (Serial_Number[4]/0x10%0x10)*0x10000000 + (Serial_Number[4]%0x10)*0x1000000 + (Serial_Number[5]/0x10%0x10)*0x100000 + (Serial_Number[5]%0x10)*0x10000 + (Serial_Number[6]/0x10%0x10)*0x1000 + (Serial_Number[6]%0x10)*0x100 + (Serial_Number[7]/0x10%0x10)*0x10+(Serial_Number[7]%0x10)*0x1 && rxmsg.len!=1)
//            {
//                if (rxmsg.len == 6 && rxmsg.data[1] < 0x08)
//                {
//                    //地址
//                    ID_Number = rxmsg.data[0];
//                    //脉冲信号或持续信号
//                    Butt.short_long[rxmsg.data[1]-1] = rxmsg.data[2];
//                    //反馈灯的开启与关闭
//                    Break.on_off[rxmsg.data[1]-1]     = rxmsg.data[3];
//                    //反馈灯id
//                    Break.it_id[rxmsg.data[1]-1]     = rxmsg.data[4];
//                    //反馈灯的状态
//                    Break.it_state[rxmsg.data[1]-1]     = rxmsg.data[5];
//                }else if (rxmsg.len == 6 && rxmsg.data[1] > 0x07) {
//                    //地址
//                    ID_Number = rxmsg.data[0];
//                    for (int x = 0; x < 10; x++)
//                    {
//                        if (Relay.Sava_id[rxmsg.data[1]-0x08][x] == 0x00)
//                        {
//                            Relay.Sava_id[rxmsg.data[1]-0x08][x] = rxmsg.data[2];
//                            //指令
//                            Relay.Sava_order[rxmsg.data[1]-0x08][x] = rxmsg.data[3];
//                            //更改的状态
//                            Relay.Sava_state[rxmsg.data[1]-0x08][x] = rxmsg.data[4];
//                            //延时
//                            Relay.Sava_delay[rxmsg.data[1]-0x08][x] = rxmsg.data[5];
//                            break;
//                        }
//                    }
//                }else if (rxmsg.len == 2)
//                {
//                    if (sp == 0) {
//                        Sleep_id[0] = rxmsg.data[0];
//                        Sleep_or[0] = rxmsg.data[1];
//                        sp++;
//                    } else {
//                        Sleep_id[1] = rxmsg.data[0];
//                        Sleep_or[1] = rxmsg.data[1];
//                    }
//                }
//            }
//            else if (rxmsg.id == (Serial_Number[4]/0x10%0x10)*0x10000000 + (Serial_Number[4]%0x10)*0x1000000 + (Serial_Number[5]/0x10%0x10)*0x100000 + (Serial_Number[5]%0x10)*0x10000 + (Serial_Number[6]/0x10%0x10)*0x1000 + (Serial_Number[6]%0x10)*0x100 + (Serial_Number[7]/0x10%0x10)*0x10+(Serial_Number[7]%0x10)*0x1 && rxmsg.len == 1)
//            {
//                if (rxmsg.data[0]== 0x08)
//                {
//                    rt_pin_write(Relay.To_Relay[0], 1);//继电器动作
//                    rt_thread_mdelay(1000);
//                    rt_pin_write(Relay.To_Relay[0], 0);//继电器动作
//                }
//                else if(rxmsg.data[0]==0x09)
//                {
//                    rt_pin_write(Relay.To_Relay[1], 1);//继电器动作
//                    rt_thread_mdelay(1000);
//                    rt_pin_write(Relay.To_Relay[1], 0);//继电器动作
//                }
//                else if(rxmsg.data[0]==0x10)
//                {
//                    rt_pin_write(Relay.To_Relay[2], 1);//继电器动作
//                    rt_thread_mdelay(1000);
//                    rt_pin_write(Relay.To_Relay[2], 0);//继电器动作
//                }
//                else if(rxmsg.data[0]==0x11)
//                {
//                    rt_pin_write(Relay.To_Relay[3], 1);//继电器动作
//                    rt_thread_mdelay(1000);
//                    rt_pin_write(Relay.To_Relay[3], 0);//继电器动作
//                }
//                else if(rxmsg.data[0]==0x01)
//                {
//                    rt_pin_write(Break.LED[0], 1);
//                    rt_thread_mdelay(1000);
//                    rt_pin_write(Break.LED[0], 0);
//                }
//                else if(rxmsg.data[0]==0x02)
//                {
//                    rt_pin_write(Break.LED[1], 1);
//                    rt_thread_mdelay(1000);
//                    rt_pin_write(Break.LED[1], 0);
//                }
//                else if(rxmsg.data[0]==0x03)
//                {
//                    rt_pin_write(Break.LED[2], 1);
//                    rt_thread_mdelay(1000);
//                    rt_pin_write(Break.LED[2], 0);
//                }
//                else if(rxmsg.data[0]==0x04)
//                {
//                    rt_pin_write(Break.LED[3], 1);
//                    rt_thread_mdelay(1000);
//                    rt_pin_write(Break.LED[3], 0);
//                }
//                else if(rxmsg.data[0]==0x05)
//                {
//                    rt_pin_write(Break.LED[4], 1);
//                    rt_thread_mdelay(1000);
//                    rt_pin_write(Break.LED[4], 0);
//                }
//                else if(rxmsg.data[0]==0x06)
//                {
//                    rt_pin_write(Break.LED[5], 1);
//                    rt_thread_mdelay(1000);
//                    rt_pin_write(Break.LED[5], 0);
//                }
//            }else if (Serial_Number[8]==0xff && rxmsg.id == 0x00 && rxmsg.len==8 )  //
//            {
//                rt_enter_critical();
//                stm32_flash_erase(Serial_Number_adder, 30);
//                for (int i = 0; i < rxmsg.len; i++)
//                {
//                    Temporary[0] = rxmsg.data[i];
//                    stm32_flash_write(Serial_Number_adder+(i*4), Temporary, 1);
//                }
//                rt_exit_critical();
//                __set_FAULTMASK(1);
//                NVIC_SystemReset();
//            }else if (rxmsg.id == 0x00 && rxmsg.ide == 1 && rxmsg.data[0]==0xff && rxmsg.data[1]==0xff)
//            {
//                //
//                rt_enter_critical();
//                //id
//                Temporary[0] = ID_Number;
//                stm32_flash_write(CAN_ID_Number_adder, Temporary, 1);
//                //sleep
//                Temporary[0] = Sleep_id[0];
//                stm32_flash_write(sleep_id_adder, Temporary, 1);
//
//                Temporary[0] = Sleep_id[1];
//                stm32_flash_write(sleep_id_adder+4, Temporary, 1);
//
//                Temporary[0] = Sleep_or[0];
//                stm32_flash_write(sleep_or_adder, Temporary, 1);
//
//                Temporary[0] = Sleep_or[1];
//                stm32_flash_write(sleep_or_adder+4, Temporary, 1);
//
//                for (int tem = 0; tem < 7; tem++)
//                {
//                    Temporary[0] = Butt.short_long[tem];
//                    stm32_flash_write(long_and_short_adder+ (tem * 4), Temporary, 1);
//
//                    Temporary[0] = Break.on_off[tem];
//                    stm32_flash_write(back_led_kg_adder+ (tem * 4), Temporary, 1);
//
//                    Temporary[0] = Break.it_id[tem];
//                    stm32_flash_write(back_led_id_adder+ (tem * 4), Temporary, 1);
//
//                    Temporary[0] = Break.it_state[tem];
//                    stm32_flash_write(back_led_or_adder+ (tem * 4), Temporary, 1);
//                }
//                for (int var = 0; var < 4; var++)
//                {
//                    for (int tem = 0; tem < 10; tem++)
//                    {
//                        Temporary[0] = Relay.Sava_id[var][tem];
//                        stm32_flash_write(relay_id_adder+ (var*40)+(tem * 4), Temporary, 1);
//                        Temporary[0] = Relay.Sava_order[var][tem];
//                        stm32_flash_write(relay_or_adder+ (var*40)+(tem * 4), Temporary, 1);
//                        Temporary[0] = Relay.Sava_state[var][tem];
//                        stm32_flash_write(relay_st_adder+ (var*40)+(tem * 4), Temporary, 1);
//                        Temporary[0] = Relay.Sava_delay[var][tem];
//                        stm32_flash_write(relay_ys_adder+ (var*40)+(tem * 4), Temporary, 1);
//                    }
//                }
//                rt_exit_critical();
//                //
//                __set_FAULTMASK(1);
//                NVIC_SystemReset();
//            }else if (rxmsg.id == 0x00 && rxmsg.ide == 1 && rxmsg.data[0]==0xfe && rxmsg.data[1]==0xfe)
//            {
//                rt_enter_critical();
//                memset(Relay.Sava_id, 0, sizeof(Relay.Sava_id));
//                memset(Sleep_id, 0, sizeof(Sleep_id));
//                memset(Sleep_or, 0, sizeof(Sleep_or));
//                stm32_flash_erase(FLAG_FLASH, 2048);
//                rt_exit_critical();
//            }else if (rxmsg.id == 0x00 && rxmsg.ide == 1 && rxmsg.data[0]==0xff && rxmsg.data[1]==0xfe)
//            {
//                rxmsg.id = (Serial_Number[4]/0x10%0x10)*0x10000000 + (Serial_Number[4]%0x10)*0x1000000 + (Serial_Number[5]/0x10%0x10)*0x100000 + (Serial_Number[5]%0x10)*0x10000 + (Serial_Number[6]/0x10%0x10)*0x1000 + (Serial_Number[6]%0x10)*0x100 + (Serial_Number[7]/0x10%0x10)*0x10+(Serial_Number[7]%0x10)*0x1;
//                rxmsg.ide=1;
//                rxmsg.len=8;
//                rxmsg.data[0] = Serial_Number[0];
//                rxmsg.data[1] = Serial_Number[1];
//                rxmsg.data[2] = Serial_Number[2];
//                rxmsg.data[3] = Serial_Number[3];
//                rxmsg.data[4] = Serial_Number[4];
//                rxmsg.data[5] = Serial_Number[5];
//                rxmsg.data[6] = Serial_Number[6];
//                rxmsg.data[7] = Serial_Number[7];
//                rt_device_write(can_dev, 0, &rxmsg, sizeof(rxmsg));
//            }
//            rt_pin_write(CAN_LED, 0);
//        }
//}
//static uint8_t button_key0_read(void)
//{
//    return rt_pin_read(PIN_KEY0);
//}
//
//static uint8_t button_key1_read(void)
//{
//    return rt_pin_read(PIN_KEY1);
//}
//static uint8_t button_key2_read(void)
//{
//    return rt_pin_read(PIN_KEY2);
//}
//static uint8_t button_key3_read(void)
//{
//    return rt_pin_read(PIN_KEY3);
//}
//static uint8_t button_key4_read(void)
//{
//    return rt_pin_read(PIN_KEY4);
//}
//static uint8_t button_key5_read(void)
//{
//    return rt_pin_read(PIN_KEY5);
//}
//static uint8_t button_key6_read(void)
//{
//    return rt_pin_read(PIN_KEY6);
//}
//static void user_button_init(void)
//{
//    int i;
//    Break.LED[0] = 45; Break.LED[1] = 23; Break.LED[2] = 22; Break.LED[3] = 21; Break.LED[4] = 20; Break.LED[5] = 19; Break.LED[6] = 15;
//    Relay.To_Relay[0] = 17; Relay.To_Relay[1] = 16; Relay.To_Relay[2] = 7; Relay.To_Relay[3] = 6;
//
//    rt_pin_mode(PIN_KEY0, PIN_MODE_INPUT_PULLUP ); rt_pin_mode(PIN_KEY1, PIN_MODE_INPUT_PULLUP );
//    rt_pin_mode(PIN_KEY2, PIN_MODE_INPUT_PULLUP ); rt_pin_mode(PIN_KEY3, PIN_MODE_INPUT_PULLUP );
//    rt_pin_mode(PIN_KEY4, PIN_MODE_INPUT_PULLUP ); rt_pin_mode(PIN_KEY5, PIN_MODE_INPUT_PULLUP );
//    rt_pin_mode(PIN_KEY6, PIN_MODE_INPUT_PULLUP );
//
//    rt_pin_mode(CAN_LED, PIN_MODE_OUTPUT);rt_pin_write(CAN_LED, 0);
//
//    rt_pin_mode(Break.LED[0], PIN_MODE_OUTPUT);rt_pin_write(Break.LED[0], 0);
//    rt_pin_mode(Break.LED[1], PIN_MODE_OUTPUT);rt_pin_write(Break.LED[1], 0);
//    rt_pin_mode(Break.LED[2], PIN_MODE_OUTPUT);rt_pin_write(Break.LED[2], 0);
//    rt_pin_mode(Break.LED[3], PIN_MODE_OUTPUT);rt_pin_write(Break.LED[3], 0);
//    rt_pin_mode(Break.LED[4], PIN_MODE_OUTPUT);rt_pin_write(Break.LED[4], 0);
//    rt_pin_mode(Break.LED[5], PIN_MODE_OUTPUT);rt_pin_write(Break.LED[5], 0);
//    rt_pin_mode(Break.LED[6], PIN_MODE_OUTPUT);rt_pin_write(Break.LED[6], 1);
//
//    rt_pin_mode(Relay.To_Relay[0], PIN_MODE_OUTPUT);rt_pin_write(Relay.To_Relay[0], 0);
//    rt_pin_mode(Relay.To_Relay[1], PIN_MODE_OUTPUT);rt_pin_write(Relay.To_Relay[1], 0);
//    rt_pin_mode(Relay.To_Relay[2], PIN_MODE_OUTPUT);rt_pin_write(Relay.To_Relay[2], 0);
//    rt_pin_mode(Relay.To_Relay[3], PIN_MODE_OUTPUT);rt_pin_write(Relay.To_Relay[3], 0);
//
//    rt_memset(&user_button[0], 0x0, sizeof(user_button));
//    //
//    user_button[USER_BUTTON_0].usr_button_read = button_key0_read;
//    user_button[USER_BUTTON_0].cb = (flex_button_response_callback)btn_0_cb;
//    //
//    user_button[USER_BUTTON_1].usr_button_read = button_key1_read;
//    user_button[USER_BUTTON_1].cb = (flex_button_response_callback)btn_1_cb;
//    //
//    user_button[USER_BUTTON_2].usr_button_read = button_key2_read;
//    user_button[USER_BUTTON_2].cb = (flex_button_response_callback)btn_2_cb;
//    //
//    user_button[USER_BUTTON_3].usr_button_read = button_key3_read;
//    user_button[USER_BUTTON_3].cb = (flex_button_response_callback)btn_3_cb;
//    //
//    user_button[USER_BUTTON_4].usr_button_read = button_key4_read;
//    user_button[USER_BUTTON_4].cb = (flex_button_response_callback)btn_4_cb;
//    //
//    user_button[USER_BUTTON_5].usr_button_read = button_key5_read;
//    user_button[USER_BUTTON_5].cb = (flex_button_response_callback)btn_5_cb;
//    //
//    user_button[USER_BUTTON_6].usr_button_read = button_key6_read;
//    user_button[USER_BUTTON_6].cb = (flex_button_response_callback)btn_6_cb;
//    for (i = 0; i < USER_BUTTON_MAX; i ++)
//    {
//        user_button[i].pressed_logic_level = 0;
//        user_button[i].click_start_tick = 15;
//        user_button[i].short_press_start_tick = 0;
//        user_button[i].long_press_start_tick =  25;
//        user_button[i].long_hold_start_tick = 30;
//        flex_button_register(&user_button[i]);
//    }
//}
//int flex_button_main(void)
//{
//    rt_uint8_t size[1];
//    rt_thread_t Butt_thread = RT_NULL;
//    rt_thread_t Can_receive = RT_NULL;
//    rt_thread_t Relay_A1    = RT_NULL;
//    rt_thread_t Relay_A2    = RT_NULL;
//    rt_thread_t Relay_A3    = RT_NULL;
//    rt_thread_t Relay_A4    = RT_NULL;
//    rt_thread_t Back    = RT_NULL;
//    rt_thread_t Order   = RT_NULL;
//
//    char can_name[RT_NAME_MAX];
//    rt_uint32_t timeout = 1;        /* 溢出时间，单位：秒 */
//    char device_name[RT_NAME_MAX];
//
//    rt_strncpy(can_name, CAN_DEV_NAME, RT_NAME_MAX);
//
//    can_dev = rt_device_find(can_name);
//
//    rt_sem_init(&rx_sem,     "rx_sem", 0, RT_IPC_FLAG_FIFO);
//
//    rt_device_open(can_dev, RT_DEVICE_FLAG_INT_RX|RT_DEVICE_FLAG_INT_TX);
//
//    /* 判断命令行参数是否给定了设备名称 */
//    /* 根据设备名称查找看门狗设备，获取设备句柄 */
//    wdg_dev = rt_device_find(device_name);
//    if (!wdg_dev)
//    {
//        return RT_ERROR;
//    }
//
//    /* 设置看门狗溢出时间 */
//    rt_device_control(wdg_dev, RT_DEVICE_CTRL_WDT_SET_TIMEOUT, &timeout);
//    /* 启动看门狗 */
//    rt_device_control(wdg_dev, RT_DEVICE_CTRL_WDT_START, RT_NULL);
//    /* 设置空闲线程回调函数 */
//    rt_thread_idle_sethook(idle_hook);
//    Serial_Number[8]=0x1f;
//    //输出发送的指令
//    Serial_Number[0] = 0x20;Serial_Number[1] = 0x04;Serial_Number[2] = 0x22;Serial_Number[3] = 0x10;
//    Serial_Number[4] = 0x00;Serial_Number[5] = 0x00;Serial_Number[6] = 0x00;Serial_Number[7] = 0x01;
////    stm32_flash_read(Serial_Number_adder,     size, 1);Serial_Number[0] = size[0];
////    stm32_flash_read(Serial_Number_adder+4,   size, 1);Serial_Number[1] = size[0];
////    stm32_flash_read(Serial_Number_adder+8,   size, 1);Serial_Number[2] = size[0];
////    stm32_flash_read(Serial_Number_adder+12,  size, 1);Serial_Number[3] = size[0];
////    stm32_flash_read(Serial_Number_adder+16,  size, 1);Serial_Number[4] = size[0];
////    stm32_flash_read(Serial_Number_adder+20,  size, 1);Serial_Number[5] = size[0];
////    stm32_flash_read(Serial_Number_adder+24,  size, 1);Serial_Number[6] = size[0];
////    stm32_flash_read(Serial_Number_adder+28,  size, 1);Serial_Number[7] = size[0];
//    if (Serial_Number[0] != 0)
//    {
//        user_button_init();
//        //CAN_ID
//        rt_thread_delay(100);
//        rt_enter_critical();
//        stm32_flash_read(CAN_ID_Number_adder,    size, 1);ID_Number = size[0];
//        //
//        stm32_flash_read(sleep_id_adder,    size, 1);  Sleep_id[0] = size[0];
//        stm32_flash_read(sleep_id_adder+4,    size, 1);Sleep_id[1] = size[0];
//        stm32_flash_read(sleep_or_adder,    size, 1);  Sleep_or[0] = size[0];
//        stm32_flash_read(sleep_or_adder+4,    size, 1);Sleep_or[1] = size[0];
//
//        for (int tem = 0; tem < 7; tem++)
//        {
//            stm32_flash_read(long_and_short_adder+ (tem * 4), size, 1); Butt.short_long[tem] = size[0];
//            stm32_flash_read(back_led_kg_adder+ (tem * 4),    size, 1); Break.on_off[tem]    = size[0];
//            stm32_flash_read(back_led_id_adder+ (tem * 4),    size, 1); Break.it_id[tem]     = size[0];
//            stm32_flash_read(back_led_or_adder+ (tem * 4),    size, 1); Break.it_state[tem]  = size[0];
//
//        }
//        for (int var = 0; var < 4; var++)
//        {
//           for (int tem = 0; tem < 10; tem++)
//           {
//               stm32_flash_read(relay_id_adder+ (var*40)+(tem * 4),    size, 1);Relay.Sava_id[var][tem] = size[0];
//               stm32_flash_read(relay_or_adder+ (var*40)+(tem * 4),    size, 1);Relay.Sava_order[var][tem] = size[0];
//               stm32_flash_read(relay_st_adder+ (var*40)+(tem * 4),    size, 1);Relay.Sava_state[var][tem] = size[0];
//               stm32_flash_read(relay_ys_adder+ (var*40)+(tem * 4),    size, 1);Relay.Sava_delay[var][tem] = size[0];
//           }
//        }
//        rt_exit_critical();
//        Butt_thread = rt_thread_create("butt", button_scan, RT_NULL, 800, 7, 5);
//        Relay_A1    = rt_thread_create("Relay_1", Relay_puls_1, RT_NULL, 500, 6, 5);
//        Relay_A2    = rt_thread_create("Relay_2", Relay_puls_2, RT_NULL, 500, 6, 5);
//        Relay_A3    = rt_thread_create("Relay_3", Relay_puls_3, RT_NULL, 500, 6, 5);
//        Relay_A4    = rt_thread_create("Relay_4", Relay_puls_4, RT_NULL, 500, 6, 5);
//        Back        = rt_thread_create("BACK", led_back, RT_NULL, 1000, 7, 5);
//        Order       = rt_thread_create("ORDER", pwm_order, RT_NULL, 1000, 7, 5);
//
//        //信号队列
//        msg_bk_id = rt_mq_create("bk_id",2,50,RT_IPC_FLAG_FIFO);
//        msg_bk_st = rt_mq_create("bk_st",2,50,RT_IPC_FLAG_FIFO);
//        msg_bk_or = rt_mq_create("bk_or",2,50,RT_IPC_FLAG_FIFO);
//
//
//        msg_id = rt_mq_create("id",2,50,RT_IPC_FLAG_FIFO);
//        msg_or = rt_mq_create("or",2,50,RT_IPC_FLAG_FIFO);
//        msg_st = rt_mq_create("st",2,50,RT_IPC_FLAG_FIFO);
//
//
//        rt_thread_startup(Butt_thread);
//        rt_thread_startup(Relay_A1);
//        rt_thread_startup(Relay_A2);
//        rt_thread_startup(Relay_A3);
//        rt_thread_startup(Relay_A4);
//        rt_thread_startup(Back);
//        rt_thread_startup(Order);
//        hwtimer_sample();
//    }else {
//        Serial_Number[8] = 0xff;
//    }
//
//    Can_receive = rt_thread_create("rx_can", CAN_Receive, RT_NULL, 800, 6, 10);
//    rt_thread_startup(Can_receive);
//    return 0;
//}
