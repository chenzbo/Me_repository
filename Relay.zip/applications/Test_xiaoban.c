//#define DBG_TAG "main"
//#define DBG_LVL DBG_LOG
//#include <board.h>
//#include <rtdevice.h>
//#include <rtthread.h>
//#include "flexible_button.h"
//#include <stdint.h>
//#include <stdlib.h>
//#include <board.h>
//#include <rtdbg.h>
//
//#define CAN_LED_PIN    GET_PIN(A, 4)//通信 改版前PA2 改版后PA4
//#define PIN_KEY0        GET_PIN(A, 10)
//#define PIN_KEY1        GET_PIN(A, 8)
//#define PIN_KEY2        GET_PIN(B, 14)
//#define PIN_KEY3        GET_PIN(B, 13)
//#define PIN_KEY4        GET_PIN(B, 15)
//#define PIN_KEY5        GET_PIN(A, 9)
//#define PIN_KEY6        GET_PIN(B, 12)
//rt_uint8_t  FK_PIN[6][2];            //开启或关闭
//#define JDQ_1_K        GET_PIN(B, 1)//GET_PIN(B, 8)//改版前
//#define JDQ_1_G        GET_PIN(B, 0)//GET_PIN(C, 14)
//#define JDQ_2_K        GET_PIN(A, 7)//GET_PIN(B, 0)
//#define JDQ_2_G        GET_PIN(A, 6)//GET_PIN(B, 1)
//#define JDQ_3_K        GET_PIN(B, 8)//GET_PIN(A, 7)
//#define JDQ_3_G        GET_PIN(C, 14)//GET_PIN(A, 6)
//void test(void)
//{
//    FK_PIN[0][1] = 45;FK_PIN[1][1] = 23;FK_PIN[2][1] = 22;FK_PIN[3][1] = 21;FK_PIN[4][1] = 20;FK_PIN[5][1] = 19;FK_PIN[6][1] = 15;
//    rt_pin_mode(PIN_KEY0, PIN_MODE_INPUT_PULLUP ); rt_pin_mode(PIN_KEY1, PIN_MODE_INPUT_PULLUP );
//    rt_pin_mode(PIN_KEY2, PIN_MODE_INPUT_PULLUP ); rt_pin_mode(PIN_KEY3, PIN_MODE_INPUT_PULLUP );
//    rt_pin_mode(PIN_KEY4, PIN_MODE_INPUT_PULLUP ); rt_pin_mode(PIN_KEY5, PIN_MODE_INPUT_PULLUP );
//    rt_pin_mode(PIN_KEY6, PIN_MODE_INPUT_PULLUP );
//
//    rt_pin_mode(FK_PIN[0][1], PIN_MODE_OUTPUT);    FK_PIN[0][0] = 0x01;rt_pin_write(FK_PIN[0][1], 0);
//    rt_pin_mode(FK_PIN[1][1], PIN_MODE_OUTPUT);    FK_PIN[1][0] = 0x01;rt_pin_write(FK_PIN[1][1], 0);
//    rt_pin_mode(FK_PIN[2][1], PIN_MODE_OUTPUT);    FK_PIN[2][0] = 0x01;rt_pin_write(FK_PIN[2][1], 0);
//    rt_pin_mode(FK_PIN[3][1], PIN_MODE_OUTPUT);    FK_PIN[3][0] = 0x01;rt_pin_write(FK_PIN[3][1], 0);
//    rt_pin_mode(FK_PIN[4][1], PIN_MODE_OUTPUT);    FK_PIN[4][0] = 0x01;rt_pin_write(FK_PIN[4][1], 0);
//    rt_pin_mode(FK_PIN[5][1], PIN_MODE_OUTPUT);    FK_PIN[5][0] = 0x01;rt_pin_write(FK_PIN[5][1], 0);
//    rt_pin_mode(FK_PIN[6][1], PIN_MODE_OUTPUT);    FK_PIN[6][0] = 0x01;rt_pin_write(FK_PIN[6][1], 0);
//
//    rt_pin_mode(JDQ_1_K, PIN_MODE_OUTPUT);rt_pin_write(JDQ_1_K, 0);
//    rt_pin_mode(JDQ_1_G, PIN_MODE_OUTPUT);rt_pin_write(JDQ_1_G, 0);
//    rt_pin_mode(JDQ_2_K, PIN_MODE_OUTPUT);rt_pin_write(JDQ_2_K, 0);
//    rt_pin_mode(JDQ_2_G, PIN_MODE_OUTPUT);rt_pin_write(JDQ_2_G, 0);
//    rt_pin_mode(JDQ_3_K, PIN_MODE_OUTPUT);rt_pin_write(JDQ_3_K, 0);
//    rt_pin_mode(JDQ_3_G, PIN_MODE_OUTPUT);rt_pin_write(JDQ_3_G, 0);
//}
//static struct rt_thread LED_Thread;
//
//
//static void LED_CAN(void *arg)
//{
//    while (1)
//    {
//        if (rt_pin_read(PIN_KEY0) == 0)
//        {
//            rt_thread_mdelay(20);
//            if (rt_pin_read(PIN_KEY0) == 0)
//            {
//                rt_pin_write(JDQ_1_K, 1);
//                rt_pin_write(FK_PIN[0][1], 1);
//                while(rt_pin_read(PIN_KEY0) == 1);
//                rt_pin_write(JDQ_1_K, 0);
//                rt_pin_write(FK_PIN[0][1], 0);
//            }
//        }else if (rt_pin_read(PIN_KEY1) == 0) {
//            rt_thread_mdelay(20);
//            if (rt_pin_read(PIN_KEY1) == 0)
//            {
//                rt_pin_write(JDQ_1_G, 1);
//                rt_pin_write(FK_PIN[1][1], 1);
//                while(rt_pin_read(PIN_KEY1) == 1);
//                rt_pin_write(JDQ_1_G, 0);
//                rt_pin_write(FK_PIN[1][1], 0);
//            }
//        }else if (rt_pin_read(PIN_KEY2) == 0) {
//            rt_thread_mdelay(20);
//            if (rt_pin_read(PIN_KEY2) == 0)
//            {
//                rt_pin_write(JDQ_2_K, 1);
//                rt_pin_write(FK_PIN[2][1], 1);
//                while(rt_pin_read(PIN_KEY2) == 1);
//                rt_pin_write(JDQ_2_K, 0);
//                rt_pin_write(FK_PIN[2][1], 0);
//            }
//        }else if (rt_pin_read(PIN_KEY3) == 0) {
//            rt_thread_mdelay(20);
//            if (rt_pin_read(PIN_KEY3) == 0)
//            {
//                rt_pin_write(JDQ_2_G, 1);
//                rt_pin_write(FK_PIN[3][1], 1);
//                while(rt_pin_read(PIN_KEY3) == 1);
//                rt_pin_write(JDQ_2_G, 0);
//                rt_pin_write(FK_PIN[3][1], 0);
//            }
//        }else if (rt_pin_read(PIN_KEY4) == 0) {
//            rt_thread_mdelay(20);
//            if (rt_pin_read(PIN_KEY4) == 0)
//            {
//                rt_pin_write(JDQ_3_K, 1);
//                rt_pin_write(FK_PIN[4][1], 1);
//                while(rt_pin_read(PIN_KEY4) == 1);
//                rt_pin_write(JDQ_3_K, 0);
//                rt_pin_write(FK_PIN[4][1], 0);
//            }
//        }else if (rt_pin_read(PIN_KEY5) == 0) {
//            rt_thread_mdelay(20);
//            if (rt_pin_read(PIN_KEY5) == 0)
//            {
//                rt_pin_write(JDQ_3_G, 1);
//                rt_pin_write(FK_PIN[5][1], 1);
//                while(rt_pin_read(PIN_KEY5) == 1);
//                rt_pin_write(JDQ_3_G, 0);
//                rt_pin_write(FK_PIN[5][1], 0);
//            }
//        }else if (rt_pin_read(PIN_KEY6) == 0) {
//            rt_thread_mdelay(20);
//            if (rt_pin_read(PIN_KEY6) == 0)
//            {
//                rt_pin_write(FK_PIN[6][1], 1);
//                while(rt_pin_read(PIN_KEY6) == 1);
//                rt_pin_write(FK_PIN[6][1], 0);
//            }
//        }
//
//    }
//}
//
////VECT_TAB_OFFSET
//int main(void)
//{
//    rt_uint8_t LED_thread_stack[250];
//    rt_pin_mode(CAN_LED_PIN, PIN_MODE_OUTPUT);
//    rt_thread_init(&LED_Thread, "CAN_LED", LED_CAN, RT_NULL, LED_thread_stack, 250, 10, 10);
//    rt_thread_startup(&LED_Thread);
//    test();
//    while (1)
//    {
//        rt_pin_write(CAN_LED_PIN,1);
//        rt_thread_mdelay(500);
//        rt_pin_write(CAN_LED_PIN,0);
//        rt_thread_mdelay(500);
//    }
//    return RT_EOK;
//}
