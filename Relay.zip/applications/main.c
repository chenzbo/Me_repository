/*
 * Copyright (c) 2006-2019, RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2019-03-09     RT-Thread    first version
 */

#include <rtthread.h>
#include <board.h>
#include <rtdevice.h>
#define DBG_TAG "main"
#define DBG_LVL DBG_LOG
#include <rtdbg.h>
//#define ADC_DEV_NAME       "adc1"

#define CAN_LED_PIN    GET_PIN(A, 4)//通信 改版前PA2 改版后PA4
static struct rt_thread LED_Thread;
//
//static rt_adc_device_t adc_dev;     //adc句柄
//
//rt_uint32_t value;

//看门狗
#define WDT_DEVICE_NAME    "wdt"    /* 看门狗设备名称 */
static rt_device_t wdg_dev;         /* 看门狗设备句柄 */
rt_uint32_t timeout = 10;        /* 溢出时间，单位：秒 */
char device_name[RT_NAME_MAX];

void MX_CAN_Init(void);
void MX_TIM3_Init(void);
//void MX_ADC1_Init(void);
int flex_button_main(void);


static void LED_CAN(void *arg)
{
//    rt_uint8_t  Index;
    while (1)
    {
        rt_pin_write(CAN_LED_PIN,1);
        rt_thread_mdelay(500);
        rt_pin_write(CAN_LED_PIN,0);
        rt_thread_mdelay(500);
        rt_device_control(wdg_dev, RT_DEVICE_CTRL_WDT_KEEPALIVE, NULL); //喂狗
    }
}

//VECT_TAB_OFFSET
int main(void)
{
    rt_uint8_t LED_thread_stack[250];
    MX_CAN_Init();
    MX_TIM3_Init();
    flex_button_main();
    rt_pin_mode(CAN_LED_PIN, PIN_MODE_OUTPUT);
    rt_thread_init(&LED_Thread, "CAN_LED", LED_CAN, RT_NULL, LED_thread_stack, 250, 10, 10);
    rt_thread_startup(&LED_Thread);
    //看门狗
    rt_strncpy(device_name, WDT_DEVICE_NAME, RT_NAME_MAX);
    wdg_dev = rt_device_find(device_name);
    rt_device_control(wdg_dev, RT_DEVICE_CTRL_WDT_SET_TIMEOUT, &timeout);//5秒
    rt_device_control(wdg_dev, RT_DEVICE_CTRL_WDT_START, RT_NULL);

    while (1)
    {
    }
    return RT_EOK;
}
