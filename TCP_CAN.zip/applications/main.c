//2020-7-21-21-04   @OrangePeel
#include <rtthread.h>
#include <board.h>
#include <rtdevice.h>
#include <stdlib.h>
#define DBG_TAG "main"
#define DBG_LVL DBG_LOG
#include <rtdbg.h>
static struct rt_thread LED_Thread;

rt_uint8_t LED_PIN[6];

//static rt_mq_t msgqueue1 = RT_NULL;
//static rt_mq_t msgqueue2 = RT_NULL;

/* 消息队列中用到的放置消息的内存池 */
/* 用于放邮件的内存池 */
int uart_sample(void);
int RS_485_init(void);
int mb_slave_samlpe(void);
void can_sample(void);

static void LED_CAN(void *arg)
{
    while (1)
    {
        rt_pin_write(LED_PIN[5],rt_pin_read(LED_PIN[5])==1?0:1);
        rt_thread_mdelay(1500);
    }
}

int main(void)
{
    rt_uint8_t LED_thread_stack[250];
    LED_PIN[0] = 36;LED_PIN[1] = 37;LED_PIN[2] = 16;LED_PIN[3] = 17;LED_PIN[4] = 18;LED_PIN[5] = 26;
    can_sample();
    uart_sample();
    rt_pin_mode(LED_PIN[0], PIN_MODE_OUTPUT);
    rt_pin_mode(LED_PIN[5], PIN_MODE_OUTPUT);
    rt_thread_init(&LED_Thread, "CAN_LD", LED_CAN, RT_NULL, LED_thread_stack, 250, 9, 5);
    rt_thread_startup(&LED_Thread);
    while (1)
    {
        rt_thread_mdelay(100);
    }
    return RT_EOK;
}
