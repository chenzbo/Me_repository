/*
 * Copyright (c) 2006-2018, RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2019-06-21     flybreak     first version
 */

#include <rtthread.h>
#include "mb.h"
#include "user_mb_app.h"
#include <stdint.h>
#include <stdlib.h>
#include <rtdevice.h>
#include <string.h>
#include <board.h>
#include <uart_can.h>
//#include <uart_can.h>

#define SLAVE_ADDR      MB_SAMPLE_SLAVE_ADDR
#define PORT_NUM        MB_SLAVE_USING_PORT_NUM
#define PORT_BAUDRATE   MB_SLAVE_USING_PORT_BAUDRATE

#define PORT_PARITY     MB_PAR_NONE

#define MB_POLL_THREAD_PRIORITY  8
#define MB_SEND_THREAD_PRIORITY  RT_THREAD_PRIORITY_MAX - 1

#define MB_POLL_CYCLE_MS 100

extern USHORT usSRegHoldBuf[S_REG_HOLDING_NREGS];
extern USHORT usSRegInBuf[S_REG_INPUT_NREGS];
void modbus_order()
{
    struct rt_can_msg msg = {0};

    while(1)
    {
        for (int i = 0; i < 10; i++)
        {
            if (usSRegHoldBuf[i] != 0x00)
            {
                usSRegHoldBuf[i] = 0x00;
                msg.id      = OULIST[0][i];
                msg.ide     = 0;
                msg.len     = 1;
                msg.data[0] = OULIST[1][i];
                rt_device_write(can_dev_b, 0, &msg, sizeof(msg));
            }
        }
        rt_thread_mdelay(100);
    }
}
static void mb_slave_poll(void *parameter)
{
    eMBInit(MB_RTU, SLAVE_ADDR, PORT_NUM, PORT_BAUDRATE, PORT_PARITY);
    eMBEnable();

    //保持寄存器对应表，0无 1开
    //发送对应指令，只需向对应地址保持寄存器写入 01即可。
    //例如OULIST[1][0] 即储存了地址为01 指令为01的   通过发送01 06 00 00 00 01 48 0a即可
    //下列数组需参考上位机生成的逻辑文件填写
    OULIST[0][0] = 0x01;OULIST[1][0] = 0x01;    //1地址,2指令

    OULIST[0][1] = 0x01;OULIST[1][1] = 0x02;

    OULIST[0][2] = 0x01;OULIST[1][2] = 0x03;

    OULIST[0][3] = 0x01;OULIST[1][3] = 0x04;

    OULIST[0][4] = 0x01;OULIST[1][4] = 0x05;

    OULIST[0][5] = 0x01;OULIST[1][5] = 0x06;
    //输入寄存器对应表
    //如果想获取设备继电器状态，只需读取输入寄存器的值即可 01 是打开状态，00是关闭状态
    //下列数组需参考上位机生成的逻辑文件填写
    INLIST[0][0] = 0x01;INLIST[1][0] = 0x08;    //1地址 ,继电器值

    INLIST[0][1] = 0x01;INLIST[1][1] = 0x09;

    INLIST[0][2] = 0x01;INLIST[1][2] = 0x0a;

    INLIST[0][3] = 0x01;INLIST[1][3] = 0x0b;


    for (int x = 0; x < 100; x++)
    {
        usSRegHoldBuf[x] = 0x00;
    }
    while (1)
    {
        eMBPoll();
        rt_thread_mdelay(MB_POLL_CYCLE_MS);
    }
}


static rt_err_t uart_input1(rt_device_t dev, rt_size_t size)
{
    rt_sem_release(&uart_sem_a);
    return RT_EOK;
}
static rt_err_t uart_input2(rt_device_t dev, rt_size_t size)
{
    rt_sem_release(&uart_sem_b);
    return RT_EOK;
}

static void uart_1_rx(void *parameter)
{

}

static void uart_1_tx(void *parameter)
{
    struct rt_can_msg msg = {0};
    rt_uint8_t ch[1], uart_a_index=0;
    ch[0] = 0;
    while (1)
    {
        rt_sem_take(&uart_sem_a, RT_WAITING_FOREVER);
        rt_device_read(uart_dev_a, -1, ch, 1);
        uart_buff[uart_a_index] = ch[0];
        uart_a_index++;
        rt_pin_write(CAN2_LED, 1);
        if (uart_buff[0]==0x1f && uart_buff[uart_a_index-1]==0x2f)//设置地址
        {
            //目标NS地址
            msg.id  = ((uart_buff[1]/0x10)%0x10)*0x10000000+((uart_buff[1])%0x10)*0x1000000+((uart_buff[2]/0x10)%0x10)*0x100000+((uart_buff[2])%0x10)*0x10000+((uart_buff[3]/0x10)%0x10)*0x1000+((uart_buff[3])%0x10)*0x100+((uart_buff[4]/0x10)%0x10)*0x10+((uart_buff[4])%0x10)*0x01;
            msg.ide = 1;
            if (uart_a_index == 12 && uart_buff[6] < 0x08)
            {
                //地址
                msg.data[0]= uart_buff[5];
                //IO编号
                msg.data[1]= uart_buff[6];
                //脉冲信号或持续信号
                msg.data[2]= uart_buff[7];
                //反馈灯的开启与关闭
                msg.data[3]= uart_buff[8];
                //反馈灯接收的地址
                msg.data[4]= uart_buff[9];
                //反馈灯接收的指令
                msg.data[5]= uart_buff[10];
                msg.len = 6;
            }else if(uart_a_index == 12 && uart_buff[6] > 0x07){
                msg.data[0]= uart_buff[5];
                msg.data[1]= uart_buff[6];
                msg.data[2]= uart_buff[7];
                msg.data[3]= uart_buff[8];
                msg.data[4]= uart_buff[9];
                msg.data[5]= uart_buff[10];
                msg.len = 6;
            }else {
                msg.data[0]= uart_buff[5];
                msg.data[1]= uart_buff[6];
                msg.len = 2;
            }
            uart_a_index=0;
            memset(uart_buff, 0, sizeof(uart_buff));
            rt_device_write(can_dev_b, 0, &msg, sizeof(msg));
        }else if (uart_buff[0]==0xf1 && uart_buff[1]==0xff)
        {
            msg.id  = 0x00;
            msg.ide = 1;
            msg.len = 2;
            uart_a_index=0;
            msg.data[0] = 0xff;
            msg.data[1] = 0xff;
            memset(uart_buff, 0, sizeof(uart_buff));
            rt_device_write(can_dev_b, 0, &msg, sizeof(msg));
        }else if (uart_buff[0]==0xf1 && uart_buff[1]==0xfe)
        {
            msg.id  = 0x00;
            msg.ide = 1;
            msg.len = 2;
            uart_a_index=0;
            msg.data[0] = 0xfe;
            msg.data[1] = 0xfe;
            memset(uart_buff, 0, sizeof(uart_buff));
            rt_device_write(can_dev_b, 0, &msg, sizeof(msg));
        }else if (uart_buff[0]==0xff && uart_buff[1]==0xfe)
        {
            msg.id  = 0x00;
            msg.ide = 1;
            msg.len = 2;
            msg.data[0] = 0xff;
            msg.data[1] = 0xfe;
            uart_a_index=0;
            memset(uart_buff, 0, sizeof(uart_buff));
            rt_device_write(can_dev_b, 0, &msg, sizeof(msg));
        }else if (uart_buff[0]==0xfe && uart_buff[uart_a_index-1]==0xf1)
        {
            msg.id  = ((uart_buff[1]/0x10)%0x10)*0x10000000+((uart_buff[1])%0x10)*0x1000000+((uart_buff[2]/0x10)%0x10)*0x100000+((uart_buff[2])%0x10)*0x10000+((uart_buff[3]/0x10)%0x10)*0x1000+((uart_buff[3])%0x10)*0x100+((uart_buff[4]/0x10)%0x10)*0x10+((uart_buff[4])%0x10)*0x01;
            msg.ide = 1;
            msg.len = 1;
            msg.data[0] = uart_buff[5];
            memset(uart_buff, 0, sizeof(uart_buff));
            rt_device_write(can_dev_b, 0, &msg, sizeof(msg));
            uart_a_index=0;
        }
        rt_pin_write(CAN2_LED, 0);
    }
}
static void uart_2_rx(void *parameter)
{

}
static void uart_2_tx(void *parameter)
{
    struct rt_can_msg uart_to_can_2 = {0};
    rt_uint16_t uart_date[20],uart_b_index=0,date[20],Number=0,jx = 0;
    rt_uint16_t ch[1];
    ch[0] = 0;
    while(1)
    {
        rt_sem_take(&uart_sem_b, RT_WAITING_FOREVER);
        rt_device_read(uart_dev_b, -1, ch, 1);
        if(wifi_init_index==1)
        {
            uart_date[uart_b_index] = ch[0];
            uart_b_index++;
            if (uart_date[0]==0x30 && uart_date[uart_b_index-1]==0x0a) {
                uart_b_index = 0;
                memset(uart_date, 0, sizeof(uart_date));
            }
            rt_pin_write(CAN2_LED, 1);
            if ((uart_b_index == 12) || (jx == 1))//设置地址
            {
                if (uart_date[uart_b_index-1] == 0x3a || (uart_date[uart_b_index-1] == 0x00 && uart_date[uart_b_index-2] == 0x3a))
                {
                    if ((uart_date[uart_b_index-1] == 0x00 && uart_date[uart_b_index-2] == 0x3a)) {
                        date[Number] = uart_date[uart_b_index-1];
                        Number++;
                    }
                    uart_b_index = 0;
                    jx = 1;
                }else {
                    date[Number] = uart_date[uart_b_index-1];
                    uart_b_index = 0;
                    Number++;
                }
                if (date[0]==0x1f && date[Number-1]==0x2f)//设置地址
                {
                    //目标NS地址
                    uart_to_can_2.id  = ((date[1]/0x10)%0x10)*0x10000000+((date[1])%0x10)*0x1000000+((date[2]/0x10)%0x10)*0x100000+((date[2])%0x10)*0x10000+((date[3]/0x10)%0x10)*0x1000+((date[3])%0x10)*0x100+((date[4]/0x10)%0x10)*0x10+((date[4])%0x10)*0x01;
                    uart_to_can_2.ide = 1;
                    if (Number == 12 && date[6] < 0x08)
                    {
                        //地址
                        uart_to_can_2.data[0]= date[5];
                        //IO编号
                        uart_to_can_2.data[1]= date[6];
                        //脉冲信号或持续信号
                        uart_to_can_2.data[2]= date[7];
                        //反馈灯的开启与关闭
                        uart_to_can_2.data[3]= date[8];
                        //反馈灯接收的地址
                        uart_to_can_2.data[4]= date[9];
                        //反馈灯接收的指令
                        uart_to_can_2.data[5]= date[10];
                        uart_to_can_2.len = 6;
                    }else if(Number == 12 && date[6] > 0x07){
                        uart_to_can_2.data[0]= date[5];
                        uart_to_can_2.data[1]= date[6];
                        uart_to_can_2.data[2]= date[7];
                        uart_to_can_2.data[3]= date[8];
                        uart_to_can_2.data[4]= date[9];
                        uart_to_can_2.data[5]= date[10];
                        uart_to_can_2.len = 6;
                    }else {
                        uart_to_can_2.data[0]= date[5];
                        uart_to_can_2.data[1]= date[6];
                        uart_to_can_2.len = 2;
                    }
                    jx = Number=0;
                    memset(date, 0, sizeof(date));
                    memset(uart_date, 0, sizeof(uart_date));
                    rt_device_write(can_dev_b, 0, &uart_to_can_2, sizeof(uart_to_can_2));
                }else if (date[0]==0xf1 && date[1]==0xff)
                {
                    uart_to_can_2.id  = 0x00;
                    uart_to_can_2.ide = 1;
                    uart_to_can_2.len = 2;
                    uart_to_can_2.data[0] = 0xff;
                    uart_to_can_2.data[1] = 0xff;
                    rt_device_write(can_dev_b, 0, &uart_to_can_2, sizeof(uart_to_can_2));
                    memset(date, 0, sizeof(date));
                    memset(uart_date, 0, sizeof(uart_date));
                    jx = Number=0;
                }else if (date[0]==0xf1 && date[1]==0xfe)
                {
                    uart_to_can_2.id  = 0x00;
                    uart_to_can_2.ide = 1;
                    uart_to_can_2.len = 2;
                    uart_to_can_2.data[0] = 0xfe;
                    uart_to_can_2.data[1] = 0xfe;
                    rt_device_write(can_dev_b, 0, &uart_to_can_2, sizeof(uart_to_can_2));
                    memset(date, 0, sizeof(date));
                    memset(uart_date, 0, sizeof(uart_date));
                    jx = Number=0;
                }
            }else if (date[0]==0xfe && date[Number-1]==0xf1)
            {
                uart_to_can_2.id  = ((date[1]/0x10)%0x10)*0x10000000+((date[1])%0x10)*0x1000000+((date[2]/0x10)%0x10)*0x100000+((date[2])%0x10)*0x10000+((date[3]/0x10)%0x10)*0x1000+((date[3])%0x10)*0x100+((date[4]/0x10)%0x10)*0x10+((date[4])%0x10)*0x01;
                uart_to_can_2.ide = 1;
                uart_to_can_2.len = 1;
                uart_to_can_2.data[0] = date[5];
                memset(date, 0, sizeof(date));
                rt_device_write(can_dev_b, 0, &uart_to_can_2, sizeof(uart_to_can_2));
                Number=0;
            }
            rt_pin_write(CAN2_LED, 0);
        }else {
            ch[0] = 0;
        }
    }
}

void wifi_init(void)
{

//    char tm1[] = "AT+CWMODE_DEF=3\r\n" ,tm2[] = "AT+RST\r\n" ,tm3[] = "AT+CWJAP_DEF=\"stzn\",\"1234569870\"\r\n", tm4[] = "AT+CIPMUX=1\r\n";//,tm5[] = "AT+CIPSTART\r\n"
//    char tcp[] = "AT+CIPSERVER=1,1011\r\n" ,RxandTx[] = "AT+CIPMODE=1\r\nAT+CIPSEND\r\n";
//    rt_device_write(uart_dev_b, 0, tm1 , sizeof(tm1));
//    rt_thread_mdelay(100);
//    rt_device_write(uart_dev_b, 0, tm2 , sizeof(tm2));
//    rt_thread_mdelay(3000);
//    rt_device_write(uart_dev_b, 0, tm3 , sizeof(tm3));
//    rt_thread_mdelay(6000);
//    rt_device_write(uart_dev_b, 0, tm4 , sizeof(tm4));
////    rt_thread_mdelay(500);
////    rt_device_write(uart_dev_b, 0, tm5 , sizeof(tm5));
//    rt_thread_mdelay(500);
//    rt_device_write(uart_dev_b, 0, tcp , sizeof(tcp));
//    rt_thread_mdelay(2000);
//    rt_device_write(uart_dev_b, 0, RxandTx , sizeof(RxandTx));
//    rt_thread_mdelay(500);
    wifi_init_index = 1;
}

void uart_sample()
{

    rt_thread_t uart_a_1,uart_a_2;                      /* 串口1*/
    rt_thread_t uart_b_1,uart_b_2;                      /* */
    rt_thread_t modbus;
    uart_dev_a = rt_device_find(USART);
    uart_dev_b = rt_device_find(USART5);

    rt_sem_init(&uart_sem_a, "Uart_1", 0, RT_IPC_FLAG_FIFO);
    rt_sem_init(&uart_sem_b, "Uart_2", 0, RT_IPC_FLAG_FIFO);

    rt_device_open(uart_dev_a, RT_DEVICE_FLAG_INT_RX);
    rt_device_open(uart_dev_b, RT_DEVICE_FLAG_INT_RX);

    rt_device_set_rx_indicate(uart_dev_a, uart_input1);
    rt_device_set_rx_indicate(uart_dev_b, uart_input2);

    modbus   = rt_thread_create("m_b", mb_slave_poll, RT_NULL, 512, 9, 9);

    uart_a_1 = rt_thread_create("1_0", uart_1_tx, RT_NULL, 1500, 9, 10);
    uart_a_2 = rt_thread_create("1_1", uart_1_rx, RT_NULL, 900, 10, 10);

    uart_b_1 = rt_thread_create("2_0", uart_2_tx, RT_NULL, 1500, 9, 10);
    uart_b_2 = rt_thread_create("2_1", uart_2_rx, RT_NULL, 900, 10, 10);

    rt_thread_startup(uart_a_1);
    rt_thread_startup(uart_a_2);
    rt_thread_startup(uart_b_1);
    rt_thread_startup(uart_b_2);

    rt_thread_startup(modbus);

}
static rt_err_t can_rx_call_1(rt_device_t dev, rt_size_t size)
{
    rt_sem_release(&can_sem_a);
    return RT_EOK;
}

static void Can_RX_thread_1()
{
    rt_device_set_rx_indicate(can_dev_a, can_rx_call_1);

    while (1)
    {
    }
}
static rt_err_t can_rx_call_2(rt_device_t dev, rt_size_t size)
{
    rt_sem_release(&can_sem_b);
    return RT_EOK;
}

static void Can_RX_thread_2()
{
    struct rt_can_msg rxmsg = {0};
    rt_uint8_t sn_list_2[1];
    rt_device_set_rx_indicate(can_dev_b, can_rx_call_2);
    rt_uint8_t x=0;
    while (1)
    {

        rxmsg.hdr = -1;

        rt_sem_take(&can_sem_b, RT_WAITING_FOREVER);

        rt_device_read(can_dev_b, 0, &rxmsg, sizeof(rxmsg));

        if (rxmsg.len == 8  && rxmsg.ide == 1)
        {
            for (int i = 0; i < rxmsg.len; i++)
            {
                sn_list_2[0] = rxmsg.data[i];
                rt_device_write(uart_dev_a, 0, sn_list_2 , sizeof(sn_list_2));
                rt_thread_mdelay(10);
            }
        }else if (rxmsg.len == 2  && rxmsg.ide == 0)
        {
            rt_device_write(uart_dev_a, 0, sn_list_2 , sizeof(sn_list_2));
            for (int i = 0; i < 98; i++)
            {
                if (rxmsg.id == INLIST[0][i] && rxmsg.data[0] == INLIST[1][i])
                {
                    rxmsg.data[1] == 0x0b ? (usSRegInBuf[i] = 0x01) : (usSRegInBuf[i] = 0x00);
                }
            }
        }
//        else if (rxmsg.len == 1  && rxmsg.data[0] == 0x01 && rxmsg.id == 0x01)
//        {
//            usSRegInBuf[98] = 1;
//        }else if (rxmsg.len == 1  && rxmsg.data[0] == 0x02 && rxmsg.id == 0x02)
//        {
//            usSRegInBuf[98] = 0;
//        }

//        else if (rxmsg.len == 1  && rxmsg.data[0] == 0x01 && rxmsg.id == 0x01)
//        {
//            if(x == 0)
//            {
//                usSRegInBuf[98] = 1;
//                x++;
//            }else {
//                usSRegInBuf[98] = 0;
//                x = 0;
//            }
//        }
    }
}

void can_sample()
{
    rt_thread_t thread_1,thread_2,thread_3;
    can_dev_a = rt_device_find(CAN_1);
    can_dev_b = rt_device_find(CAN_2);

    rt_sem_init(&can_sem_a, "can_sem_a", 0, RT_IPC_FLAG_FIFO);
    rt_sem_init(&can_sem_b, "can_sem_b", 0, RT_IPC_FLAG_FIFO);

    rt_device_open(can_dev_a, RT_DEVICE_FLAG_INT_TX | RT_DEVICE_FLAG_INT_RX);
    rt_device_open(can_dev_b, RT_DEVICE_FLAG_INT_TX | RT_DEVICE_FLAG_INT_RX);

    rt_pin_mode(CAN2_LED, PIN_MODE_OUTPUT);
    rt_pin_write(CAN2_LED, 0);

    thread_3 = rt_thread_create("m_b_r", modbus_order, RT_NULL, 1024, 9, 10);
    thread_1 = rt_thread_create("can_rx1", Can_RX_thread_1, RT_NULL, 1024, 11, 10);
    thread_2 = rt_thread_create("can_rx2", Can_RX_thread_2, RT_NULL, 1024, 11, 10);

    if (thread_1 != RT_NULL && thread_2 != RT_NULL)
    {
        rt_thread_startup(thread_1);
        rt_thread_startup(thread_2);
        rt_thread_startup(thread_3);
    }
    wifi_init();
}

