#include <rtthread.h>
#include <board.h>
#include <stdlib.h>
#include <rtdevice.h>


#define RS_485_2        "uart4"

#define RS_485_2_W_R      GET_PIN(A, 8)

#define RS_485_LED        GET_PIN(B, 10)
static struct rt_semaphore rs_485_sem;
static rt_device_t dev_485_2;
rt_thread_t thread1;

static rt_err_t uart_input(rt_device_t dev, rt_size_t size)
{

    rt_sem_release(&rs_485_sem);
    return RT_EOK;

}
static void RS_485_Thread(void *parameter)
{
    rt_uint8_t rx_data[7];
    while(1)
    {
        rx_data[0] = 0x9a;
        rx_data[1] = 0x01;
        rx_data[2] = 0x01;
        rx_data[3] = 0x00;
        rx_data[4] = 0x0a;
        rx_data[5] = 0xdd;
        rx_data[6] = rx_data[1]^rx_data[2]^rx_data[3]^rx_data[4]^rx_data[5];
        rt_pin_write(RS_485_2_W_R, 1);
        rt_pin_write(RS_485_LED, 1);
        rt_device_write(dev_485_2, 0, rx_data, 7);
        rt_thread_delay(20);
        rt_pin_write(RS_485_2_W_R, 0);
        rt_thread_mdelay(500);
        rt_pin_write(RS_485_LED, 0);
        rt_thread_mdelay(500);
    }
}
int RS_485_init()
{
	struct serial_configure config;  /* 初始化配置参数 */
    rt_pin_mode(RS_485_2_W_R, PIN_MODE_OUTPUT);
    rt_pin_mode(RS_485_LED, PIN_MODE_OUTPUT);
    rt_pin_write(RS_485_LED, 0);
    rt_pin_write(RS_485_2_W_R, 0);

    config.baud_rate = BAUD_RATE_9600;        //修改波特率为 9600
    config.data_bits = DATA_BITS_8;           //数据位 8
    config.stop_bits = STOP_BITS_1;           //停止位 1
    config.bufsz     = 128;                   //修改缓冲区 buff size 为 128
    config.parity    = PARITY_NONE;           //无奇偶校验位

    dev_485_2  = rt_device_find(RS_485_2);

    rt_device_control(dev_485_2,RT_DEVICE_CTRL_CONFIG, &config);

    rt_device_open(dev_485_2,  RT_DEVICE_FLAG_INT_RX);

    rt_device_set_rx_indicate(dev_485_2, uart_input);

    thread1 = rt_thread_create("rs485", RS_485_Thread, RT_NULL, 1000, 9, 10);

    if (thread1 != RT_NULL)
    {
        rt_thread_startup(thread1);
    }
    else
    {
        return RT_ERROR;
    }
    return RT_EOK;
}
