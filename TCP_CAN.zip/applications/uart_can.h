/*
 * Copyright (c) 2006-2020, RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2020-09-08     chen1       the first version
 */
#ifndef APPLICATIONS_UART_CAN_H_
#define APPLICATIONS_UART_CAN_H_

#define USART           "uart2"
#define USART5          "uart5"                     /* UART名称 */

#define CAN_1           "can1"
#define CAN_2           "can2"                      /* CAN名称  */

//#define CAN1_LED          GET_PIN(B, 2)
#define CAN2_LED          GET_PIN(B, 2)             /* CAN通信指示灯 */

static rt_device_t can_dev_a,  can_dev_b;           /* CAN设备句柄  */

static rt_device_t uart_dev_a, uart_dev_b;          /* 串口设备句柄  */

static struct rt_semaphore can_sem_a, can_sem_b;    /* can信号句柄  */

static struct rt_semaphore uart_sem_a,uart_sem_b;   /* uart信号句柄  */

static rt_uint16_t uart_buff[1025],wifi_init_index = 0;    /* 串口接收数组 与 wifi初始索引  */

void stm32_flash_read (rt_uint32_t addr, const rt_uint8_t *buf, size_t size);

void stm32_flash_write(rt_uint32_t addr, const rt_uint8_t *buf, size_t size);

int  stm32_flash_erase(rt_uint32_t addr, size_t size);

rt_uint32_t INLIST[2][100];
rt_uint32_t OULIST[2][100];

#endif /* APPLICATIONS_UART_CAN_H_ */
